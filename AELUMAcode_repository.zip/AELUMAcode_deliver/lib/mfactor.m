% mfactor:
%       mfactor(N) gives ALL integer factors of the N
%       it differs from the matlab function factor(N)
%       which only gives PRIME factors of N
% USAGE:
%       [vfact] = mfactor(N)
%
% INPUT:
%       N       =  integer
%
% OUTPUT:
%       vfact    = vector of factors of N
%
%
function [vfact] = mfactor(N)

if ~isscalar(N)
    disp('ERROR mfactor: input must be a scalar');
    vfact = [];
    return
end
if (mod(N,1)~=0)
    disp('ERROR mfactor: input must be an integer');
    vfact = [];
    return
end

vfact = [];
nloop = sqrt(N);        % does not have to be an integer

for jfact = 1:nloop
    if (mod(N/jfact,1)==0)           % it is an integer
        vfact = [vfact jfact N/jfact];
    end
end

vfact = unique(sort(vfact));

return
