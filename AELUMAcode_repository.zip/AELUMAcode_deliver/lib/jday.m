% AELUMA public bundle
%
% jday:
%       converts yr,month, day to day-of-year
%
% History:
%       2009 Bob Woodward: originator
%       2009-11-30 Manoch: installed at DMC
%       R.2016.336 2016-12-01 IRIC DMC: public release
%
function [jday] = jday(iy,im,imd)

      jday = fix(datenum(double(iy),double(im),double(imd)) - datenum(double(iy),1,1)) + 1;
