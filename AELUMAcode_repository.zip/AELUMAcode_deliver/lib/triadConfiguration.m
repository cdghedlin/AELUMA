% triadConfiguration:
%       get location matrix for a given triad
%
% input:
%       trilats,trilons: station locations within the array
% output:
%       XR : position matrix
%
function [XR] = arrayConfiguration(trilats,trilons);

Mperdegree = 111110;                            % metres per degree of latitude

clon = mean(trilons);       % triad center
clat = mean(trilats);
% get xloc and yloc for each station within the array wrt clon,clat
% does not take elevation differences into account
lonscale = cosd(clat);
xloc = (trilons - clon)*Mperdegree*lonscale;
yloc = (trilats - clat)*Mperdegree;
% positions
XR(:,1) = xloc(:);
XR(:,2) = yloc(:);

% NOTE: the triad centers used here are approximately equal to the
% triangle centroids (exact for flat earth). could instead have used the
% incenter, but NOT the circumcenter or orthocenter
% (see http://www.mathopenref.com/trianglecentroid.html)
