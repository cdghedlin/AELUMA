% ***********************************************************************************
% ***********************************************************************************
%
%		Read in data one day at a time - (but keep code to allow for multiple days)
%
% ***********************************************************************************
% ***********************************************************************************

% choose time window
clear savelons savelats datasave

maxgap = 2;
indatadir = [aelumaDir,'IMSprocesseddata/'];

for julday=julday:julday
    fprintf('\n======== Day %d ========\n',julday);
    gapcounter=0;
    nodatacounter=0;
    
    jd1=julday; ihr1=0; imn1=00; isc1=0; 
    jd2=julday; ihr2=23; imn2=59; isc2=60;
    [mo1,day1] = jul2cal(iyr,jd1); 
    [mo2,day2] = jul2cal(iyr,jd2);
    t0=epoch(iyr,jd1,ihr1,imn1,isc1);
    tend=epoch(iyr,jd2,ihr2,imn2,isc2);
    [mo1,day1] = jul2cal(iyr,julday); 
    tjday=epoch(iyr,jd1,0,0,0);
    tcorr = tjday-t0;

% ***********************************************************************************
% ***********************************************************************************
%
%	sections 3  Read data. Run loop over each station
%
% ***********************************************************************************
% ***********************************************************************************

    fprintf('\n---> sections 3 - loop over each station\n\n');

    clear ind nstat
    nstat = length(st);

    tic
    jstat = 0;
%    fprintf('\n[INFO]T0:%0.8f Tend:%0.8f\n',t0,tend);
    fprintf('\n %d stations to read in \n',nstat);
    for istat=1:nstat

        clear fid infilename
        fsampsta = st(istat).SampleRate;
        datname = strcat(st(istat).StationCode,'_',st(istat).Element,'_',st(istat).Channel,'_',int2str(iyr),int2str(julday),'_',int2str(fsampsta),'sps');
        infilename=strcat(indatadir,datname);
        if ~isfile(infilename)
            fprintf('\n %s not found \n',datname);
            continue
        else                     % write out name to screen
            fprintf('\n %s\n',datname);
        end
    
        fid=fopen(infilename,'r');
        ts1=fread(fid,'float32');
        ts1=ts1-mean(ts1);
        fclose(fid);

  %      fprintf('\n..... Station %3i -  %s\n',istat,st(istat).StationCode);

       nsample=length(ts1); clear ind2
       nsampleexp=(tend-t0)*fsampsta;       %XX dropped the +1
       srate = round(fsampsta);
       delt = 1/srate;

       % fill in where there are gaps in data 
       alltime=t0+[0:nsampleexp-1]/srate;
       nmiss = nsampleexp-nsample;
       if nmiss > maxgap
            gapcounter=gapcounter+1;
            fprintf('   [WARN] %d pts missing, skipping record \n',nmiss); 
            continue; 
        end;

        if nmiss ~=0 % fill in gaps in data
            a = [ts1; ts1(end)];
            if (nmiss == 2);
                a = [a(1); a];
            end
        else
           a = ts1;
           t = alltime; nsample = length(a); a = a(:);
           clear alltime tfromdatabase interpamp afromdatabase tcollapsed acollapsed
        end

        jstat = jstat + 1;

% save data to matrix
        ndec = fsampsta/fsfinal;

        if ndec > 1
% lowpass filter the data first
            [outdat]=mybandpassw(a,fsampsta,0,fnyq);
            if (mod(ndec,1)==0)
                datasave(jstat,:) = outdat(1:ndec:end); clear a outdat
            else
                tq = t-t0;
%                tq2 = 0:1/fsampsta:24*3600;
%                tinterp = 0:1/fsfinal:(24*3600 - 1/fsfinal);
                tinterp = [0:1:24*3600*fsfinal-1]/fsfinal;
                dataint = interp1(tq,outdat,tinterp);       % interpolation
                datasave(jstat,:) = dataint;
            end
        else
            datasave(jstat,:) = a(1:end); clear a
%            disp('no filtering needed')
        end

        savelats(jstat)=stalats(istat);
        savelons(jstat)=stalons(istat);
        fprintf ('\n')
    end	            % END LOOP OVER STATIONS for this day
    
    fprintf('\n[INFO] time to read in data at %d stations: %f\n',jstat, toc)
    nsave = jstat;
    if (nsave==0) return; end
%   tsave = t - t0;        % time wrt start of time window
    tsave = 0:1/fsfinal:24*3600;

% ***********************************************************************************
%  plot positions of stations that have been read in
% ***********************************************************************************
        
    if makeplots ~= 0
 	   fig_h = figure(5);hold on,
 	   plot(savelons,savelats,'ko','MarkerFaceColor','r') 
 %      legend('coast','all stations','not available','array stations','Location','SouthWest')
	   hold on,   
       set (fig_h,'Position',[1 150 screenWidth screenHeight],'Color',[1 1 1]);
    end

end

clear amptmp t marker
return
