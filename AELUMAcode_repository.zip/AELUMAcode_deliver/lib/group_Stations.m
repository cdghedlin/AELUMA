% groupVor_Stations:
%       given an arbitrary group of station locations, find those that can be grouped as arrays
%       uses station locations to examine distance to other stations
%
% input:
%       stalats, stalons - stations latitudes and longitudes
%       armax - maximum radius of array (km)
%       namin - minimum number of elements in an array
% output:
%       arrayvec - vector that indicates what array each station belongs (0=none)
%       narr - number of arrays
%       marr - number of stations within each array (vector of length narr)
%       maxr - maximum radial distance of array

function [arrayvec,narr,marr,maxr] = groupVor2_Stations(stalat,stalon,armax,namin);

%  check that stalat/stalon dimensions arrays agree
nsta = length(stalat);
if length(stalon) ~= nsta
    disp('STOP in groupVor_Stations: problem with station coordinates')
    keyboard
end

iii = [1:nsta];
arrayvec = zeros(nsta,1);           % tells which array the station belongs to
narr = 0;
marr = [];
maxr = [];
scale = mean(cosd(stalat));
vorx = stalon; vory = stalat;

minlat = min(stalat);  maxlat = max(stalat);
minlon = min(stalon);  maxlon = max(stalon);


while (length(iii) >= namin);
    stalats=stalat(iii); stalons = stalon(iii);

% at each loop, find distances from each voronoi point to all stations
    nv = nsta; vkeep = zeros(nv,1);
    for jvor = 1:nv
% 1) compute distance from each voronoi point to each station
        lonscale = cosd(vory(jvor));
        vordist = sqrt((lonscale*(vorx(jvor)-stalons)).^2+(vory(jvor)-stalats).^2)*111.11;
% 2) for each voronoi point, count number of stations within armax
        ind = find(vordist<armax);
        vkeep(jvor) = length(ind);
    end

% 3) find point with highest number of stations within armax
    [nmax,imax] = max(vkeep);     % maximum number of stations in array
    if (nmax >= namin)         % there are enough stations to form an array
        narr = narr+1;
        marr(narr) = nmax;
% 4) for point with the highest number, recompute the distances and remove all stations within armax
        lonscale = cosd(vory(imax));
        vordist = sqrt((lonscale*(vorx(imax)-stalons)).^2+(vory(imax)-stalats).^2)*111.11;
        iarray = find(vordist <= armax);
        maxr(narr) = max(vordist(iarray));
        iarray = iii(iarray);
        arrayvec(iarray) = narr;
        iii = setdiff(iii,iarray);
    else
        notarray = length(find(arrayvec==0));
        if (length(iii) ~= notarray)
            disp('there is a problem at line 66 in groupVor_Stations')
            keyboard
        end
        fprintf('%d arrays, %d stations not in arrays\n',narr,notarray);
        return
    end

% at each iteration, we drop both stations (already put in arrays)
% and also test points
    ind = find(vkeep<namin); vkeep(ind) = 0.0;
    vorx = vorx(vkeep~=0);
    vory = vory(vkeep~=0);
%    hold on,plot(stalon(iarray),stalat(iarray),'bx')

% 5) do these steps recursively until no more arrays are formed
end

