% select stations to read in from local disk
%
% *********************************************************************************************
% *********************************************************************************************
%
%    section 1- set directories 
%
% *********************************************************************************************
% *********************************************************************************************
fprintf('\n---> section 1 - set directories & WS calls\n\n');

% overwrite output directory
Dir               = sprintf('%s/%4i/',detectionDir,iyr);
[s, mess, messid] = mkdir(Dir);
fprintf('[INFO] output directory: %s  %s\n', Dir, mess);

% get element locations
% fname = [aelumaDir,'IMSStations/IMSStationElementCoordinates.txt']
fname = [aelumaDir,'IMSprocesseddata/IMSStationElementCoordinates_',num2str(iyr),num2str(julday),'.txt']
fid=fopen(fname,'r');
buffer=fgetl(fid);

i=0;
st = struct('Longitude',{},'Latitude',{},'Element',{},'StationCode',{},'Channel',{},'SampleRate',{},'Onoff',{});
while (length(buffer) > 1)
  i=i+1;
  stname2(i,:) = sscanf(buffer(1:6),'%6c');
  elname(i,:) = sscanf(buffer(9:14),'%6c');
  elchan(i,:) = sscanf(buffer(15:21),'%6c');
  elloc(i,:) = str2num(buffer(22:end));
  st(i).StationCode = strtrim(stname2(i,:));
  st(i).Element = strtrim(elname(i,:)); st(i).Channel = strtrim(elchan(i,:));
  st(i).Channel(3)='Z';
  st(i).Longitude = elloc(i,2); st(i).Latitude = elloc(i,1);
  st(i).SampleRate = elloc(i,3); st(i).Onoff = elloc(i,4);
  buffer=fgetl(fid);
end
fclose(fid);

% *********************************************************************************************
% *********************************************************************************************
%
%    section 2- cull stations - several different culling methods 
%
% *********************************************************************************************
% *********************************************************************************************

fprintf('\n---> section 2 - cull stations: several different culling methods\n\n');
%
ionoff = [st.Onoff];
ii = find(ionoff ==1);
st = st(ii);                    % only keep stations available on this day

nstat      = length([st.Longitude]);
stalons    = [st.Longitude]; stalats=[st.Latitude];
fprintf('\t stations available on local disk for day %d : \t \t \t  %d\n',julday, nstat)

if makeplots ~= 0
	fig_h = figure(5);clf;
    set (fig_h,'Position',[1 150 screenWidth screenHeight],'Color',[1 1 1]);
    load coast
    hold on,geoshow(lat,long,'Color',0.01*[1 1 1])
	hold on, plot(stalons,stalats,'ko','MarkerFaceColor',0.6*[1 1 1])
	%axis([min(stalons) max(stalons) min(stalats) max(stalats)])
	axis([wlon elon southlat northlat])
end
%
% cull station lists
%
% A) only use station if sample rate is within range fsmin-fsmax
%       and sample rate is >=2*fmax (ie twice max freq of interest)
fsamp = [st.SampleRate];
ii = find( (fsamp>=fsmin) & (fsamp<=fsmax) & (fsamp>=2*fmax) );
fprintf('\t %i records have sample rates >= %d & <= %d Hz\n',length(ii),fsmin,fsmax);
fprintf('\t and >= (2*%d) samples per second \n',fmax);
st = st(ii); stalats = [st.Latitude];

if (ifregion)
% Q) get rid of stations if they are not within the region of interest
    stalons = [st.Longitude];
    stalats = [st.Latitude];
    ind = find(stalons>=lon1 & stalons<=lon2 & stalats>=lat1 & stalats<=lat2);
    st = st(ind);
    nstat=length([st.Longitude]);
    fprintf('\t stations within region of interest : \t \t \t  %d\n',nstat)
end
nstat=length([st.Latitude]);

% C) only allow if one of the channel names is correct
icomma = strfind(chan,','); nchan = 1+length(icomma);
if (nchan == 1) chann = chan;
else
    i1 = 1;
    for jj = 1:nchan-1
        chann(jj,:) = chan(i1:icomma(jj)-1);
        i1 = icomma(jj)+1;
    end
    chann(nchan,:) = chan(i1:end);
end

for jj = 1:nstat
    clear tf
    for kk = 1:nchan
        tf(kk) = strcmp(st(jj).Channel,chann(kk,:));
    end
    truefalse(jj) = sum(tf);
end
ind = find(truefalse==1); nstat = length(ind);
st = st(ind); stalons = [st.Longitude]; stalats = [st.Latitude];
fprintf('\t > channel type %s : \t %d\n\n',chan,nstat)

if makeplots ~= 0
    stalons = [st.Longitude]; stalats = [st.Latitude];
    hold on,plot(stalons,stalats,'ko','MarkerFaceColor','y')
end

% D) get rid of stations if they are too near other stations
[distmat,distmin,distmin2,distmin3] = distmatrix(stalats,stalons);
mindist = min(distmin);

while (mindist<rmin)
    ii1 = find(distmin==mindist);        % find stations with minimum interstation R
% ii1 list comprises at least 2 stations, cull the one with smallest distmin2
    [dum2,ii2] = min(distmin2(ii1));
    ii = ii1(ii2);
    kk=1:nstat; ind=setdiff(kk,ii);
    st=st(ind);
    stalats=[st.Latitude]; stalons = [st.Longitude];
    nstat=length(stalats);
    [distmat,distmin,distmin2,distmin3] = distmatrix(stalats,stalons);
    mindist = min(distmin);
%    [nstat mindist min(distmin2)]
end
fprintf('\t > %d km from nearest neighbour : \t %d\n\n',rmin,nstat)

if makeplots ~= 0
    stalats=[st.Latitude]; stalons = [st.Longitude];
    hold on,plot(stalons,stalats,'ko','MarkerFaceColor','b')
end

% D) get rid of stations that are too far from others
Dmax = 2*Rmax;
nstatold = 0;
while (nstatold < nstat)
    nstatold = nstat;
    [distmat,distmin,distmin2,distmin3] = distmatrix(stalats,stalons);
    sdsort = sort(distmat); distminarr = sdsort(namin-1,:);
    ind = find(distminarr<Dmax);
    st=st(ind); stalats=[st.Latitude]; stalons = [st.Longitude];
    nstat=length(stalats);
end
fprintf('\t < %d km from enough nearest neighbours for array: \t %d\n',Dmax,nstat)

% save list of stations
nstato=nstat; sto=st; stalatso=stalats; stalonso=stalons;

if makeplots ~= 0
	hold on,plot(stalons,stalats,'ko','MarkerFaceColor','c')
    grid
    pause(0.001)
end

clear distmat distmin distmin2 distmin3

return
