% groupVor_Stations:
%       given an arbitrary group of station locations, find those that can be grouped as arrays
%       uses voronoi points as test points to examine distance to nearest stations
%
% input:
%       stalats, stalons - stations latitudes and longitudes
%       armax - maximum radius of array (km)
%       namin - minimum number of elements in an array
% output:
%       arrayvec - vector that indicates what array each station belongs (0=none)
%       narr - number of arrays
%       marr - number of stations within each array (vector of length narr)
%       maxr - maximum radial distance of array

function [arrayvec,narr,marr,maxr] = groupVor2_Stations(stalat,stalon,armax,namin);

%  check that stalat/stalon dimensions arrays agree
nsta = length(stalat);
if length(stalon) ~= nsta
    disp('STOP in groupVor_Stations: problem with station coordinates')
    keyboard
end

iii = [1:nsta];
arrayvec = zeros(nsta,1);           % tells which array the station belongs to
narr = 0;
marr = [];
maxr = [];
scale = mean(cosd(stalat));
[vx,vy] = voronoi(scale*stalon,stalat);       % get the voronoi points
vorx = vx(1,:)/scale; vory = vy(1,:);

minlat = min(stalat);  maxlat = max(stalat);
minlon = min(stalon);  maxlon = max(stalon);
ind = find(vorx>minlon & vorx<maxlon & vory>minlat & vory<maxlat);
vorx = vorx(ind); vory = vory(ind);

% figure(2),clf,plot(stalon,stalat,'ko')
% hold on,plot(vorx,vory,'ro')
% axis([minlon maxlon minlat maxlat])

while (length(iii) >= namin);
    stalats=stalat(iii); stalons = stalon(iii);

% at each loop, find distances from each voronoi point to all stations
    nv = length(vorx); vkeep = zeros(nv,1);
    for jvor = 1:nv
% 1) compute distance from each voronoi point to each station
        lonscale = cosd(vory(jvor));
        vordist = sqrt((lonscale*(vorx(jvor)-stalons)).^2+(vory(jvor)-stalats).^2)*111.11;
% 2) for each voronoi point, count number of stations within armax
        ind = find(vordist<armax);
        vkeep(jvor) = length(ind);
    end

% 3) find voronoi point with highest number of stations within armax
    [nmax,imax] = max(vkeep);     % maximum number of stations in array
    if (nmax >= namin)         % there are enough stations to form an array
        narr = narr+1;
        marr(narr) = nmax;
% 4) for point with the highest number, recompute the distances and remove all stations within armax
        lonscale = cosd(vory(imax));
        vordist = sqrt((lonscale*(vorx(imax)-stalons)).^2+(vory(imax)-stalats).^2)*111.11;
        iarray = find(vordist <= armax);
        maxr(narr) = max(vordist(iarray));
        iarray = iii(iarray);
        arrayvec(iarray) = narr;
        iii = setdiff(iii,iarray);
    else
        notarray = length(find(arrayvec==0));
        if (length(iii) ~= notarray)
            disp('there is a problem at line 66 in groupVor_Stations')
            keyboard
        end
        fprintf('%d arrays, %d stations not in arrays\n',narr,notarray);
        return
    end

% at each iteration, we drop both stations (already put in arrays)
% and also voronoi points
    ind = find(vkeep<namin); vkeep(ind) = 0.0;
    vorx = vorx(vkeep~=0);
    vory = vory(vkeep~=0);
%    hold on,plot(stalon(iarray),stalat(iarray),'bx')

% 5) do these steps recursively until no more arrays are formed
end

% ------------- following code is to merge very closely spaced arrays

% find array centers
for jj = 1:narr
    iarr = find(arrayvec==jj);
    arrlat(jj) = mean(stalat(iarr)); lonscale = cosd(arrlat(jj));
    arrlon(jj) = mean(stalon(iarr));
    distarr = sqrt((lonscale*(arrlon(jj)-stalon(iarr))).^2+(arrlat(jj)-stalat(iarr)).^2)*111.11;
    maxr(jj) = max(distarr);
end

% figure(3),clf,plot(stalon,stalat,'ko')
% hold on,plot(arrlon,arrlat,'rx'),grid
% axis([minlon maxlon minlat maxlat])

% find any arrays that should be merged -
%   i.e. if distances between array centers < 2*maxr

iflag = 0;
for jj = 1:narr
% find the distance to other array centers
% if the distance is ~ the array dimension, merge it
    lonscale = cosd(arrlon(jj));
    dist = sqrt((lonscale*(arrlon(jj)-arrlon)).^2+(arrlat(jj)-arrlat).^2)*111.11;
    dist(jj) = max(dist);     % skip self
    ind = find(dist<2*maxr(jj));

    if isempty(ind) continue; end
    iarr = find(arrayvec==jj);
    if isempty(iarr) continue; end     % have alread merged this one

    iflag = 1;               % merging
    [ia,ib] = ismember(arrayvec,ind);
    iarrmerge = find(ia>0);
%    [jj maxr(jj) maxr(ind) dist(ind)]
%    figure(4),clf, plot(stalon(iarr),stalat(iarr),'ko')
%    hold on,plot(stalon(iarrmerge),stalat(iarrmerge),'ro')
%    plot(arrlon(jj),arrlat(jj),'kp'),plot(arrlon(ind),arrlat(ind),'rp')
    
    arrayvec(iarrmerge) = jj;
end

% iflag = 1 if any arrays have been merged

if (iflag)      % arrays have been merged, need to recompute
    clear maxr marr
    icount = 0;
    for jj = 1:narr
        iarr = find(arrayvec==jj);
        if isempty(iarr) continue; end
        arrlat  = mean(stalat(iarr));  lonscale = cosd(arrlat);
        arrlon = mean(stalon(iarr));
        icount = icount+1;
        dist = sqrt((lonscale*(arrlon-stalon(iarr))).^2+(arrlat-stalat(iarr)).^2)*111.11;
                 
        maxr(icount) = max(dist);
        marr(icount) = length(iarr);
        arrayvec(iarr) = icount;
    end
    narr = icount;
end
