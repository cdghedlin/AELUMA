%  AELUMA public bundle
%
% grid_Search:
%       find the best source location and time
%
%       Both arrival time and azimuth to source data are used as inputs
%       the best source location in a grid search == minimum L1 misfit in azimuth
%
%       given this source location, find the arrival time and slowness
%       by getting the origin time & slope of the t vs. range points
%
% input:
%	trilat,trilon : vectors of triad latitudes & longitudes
%	azmth,ttsig : azimuths and arrival times to source at each triad location
%	testlat,testlon : vectors defining search grid
%	Afit - minimum target azimuth misfit
%	iii - indices of detections under consideration
% output:
%   bestlat, bestlon -  best point in latitude and longitude (actually, center of ellipse)
%   errlat,errlon - error in latitude & longitude
%   besttime -  best time fit
%   vslow - best slope of time vs distance (best celerity)
%   AzMisfit :  sum(azmisfit)/N
%   ellipsang : angle of major axis of error ellipse
%   maxis : [1 = minor axis length; 2 = major axis length] in degrees
%   olat,olon : point with best fit (not necessarily the center of the ellipse)
%
% History:
%       Feb 9, 2021  C. de Groot-Hedlin
%
function [bestlat,bestlon,errlat,errlon,besttime,vslow,AzMisfit,ellipsang,maxis,olat,olon] = gridSearch(trilat,trilon,azmth,ttsig,testlat,testlon,Afit,iii)

SPHEROID = referenceEllipsoid('wgs84', 'km');
options = optimoptions('fminunc','Display','off');      % suppress output
nlon=length(testlon); nlat=length(testlat);
dlat = abs(testlat(2)-testlat(1));
dlon = abs(testlon(2)-testlon(1));

% angle error due to grid discretization
% divide dazmth by kmdist (distance from triad to gridpoint)
% dazmth = s/r*180/pi      (converts to degrees)
dazmth = 111.11*dlat*180/pi;

L1misfit = Afit + zeros(nlon,nlat);

% subset of detections within this particular cluster
slatx=trilat(iii); slonx=trilon(iii);
sazmthx = azmth(iii); sigtimex = ttsig(iii);
% ntriad = length(slats);

% solve for unique array locations (mean azimuths and arrival times)
ylocs = [trilat(iii); trilon(iii)];
[yulocs,ia,ic] = unique(ylocs','rows');
ntriad = max(ic);       % maximum # unique arrays + triads

% there can be wraparound error for azimuths pointing approx N (angles from 0 -360)
% fixed
[meanang,sigtimes,meanang2,maxdiff,maxdiff180] = deal(zeros(ntriad,1));
for jj = 1:ntriad
   iun = find(ic==jj);
   slats(jj) = mean(slatx(iun)); slons(jj) = mean(slonx(iun));  % should all be identical
   meanang(jj) = mean(sazmthx(iun));         % XXXXX resolve potential wrap-around problem
   sigtimes(jj) = min(sigtimex(iun));
   if (length(iun)>1)
        maxdiff(jj) = max(sazmthx(iun))-min(sazmthx(iun));
        angs180 = Csetminmax(sazmthx(iun),-180,180);
        meanang2(jj) = mean(angs180);
        maxdiff180(jj) = max(angs180)-min(angs180);
   else
        meanang2(jj) = meanang(jj);
   end
end

sazmth = meanang;
meanang2 = Csetminmax(meanang2,0,360);      % reset angles are from 0 to 360
ind = find(maxdiff180 < maxdiff);
% a higher variation implies angle wraparound error, so use
% the angle estimate corresponding to lower variation in angles
if (length(ind)>0)
   sazmth(ind) = meanang2(ind);
end
                        
% compute the L1 misfit in azimuth for each gridpoint
for ilat = 1:nlat
	for ilon = 1:nlon
		[kmdist,az] = distance(slats,slons,testlat(ilat),testlon(ilon),SPHEROID);
        misfit = abs(Csetminmax(sazmth(:)-az(:),-180,180));		% azimuth misfit
 %       ifmis = find(misfit > (Afit+dazmth./kmdist));
        L1misfit(ilon,ilat) = sum(abs(misfit)/ntriad);  %  + length(ifmis)/ntriad;  %penalize points that don't fit
    end
end
                        
% finish up ---------------------------------------------------------------------

% choose the location based on the best L1 azimuth misfit (with restrictions on misfit & slowness)
[dum,jlat] = min(min(L1misfit)); [minvalue,jlon]=min(min(L1misfit'));
AzMisfit = minvalue;            % mean azimuth misfit
olat = testlat(jlat);olon=testlon(jlon);
                                                                    
% get estimate of the location error (any fit within Na* best, at least 50 points)
Na = 2;
dsort = sort(L1misfit(:)); d50 = min(dsort(50),Afit);
ind = find(L1misfit <= max(d50,Na*minvalue));
ilats = ceil(ind/nlon);
ilons = ind - (ilats-1)*nlon;

% errors in latitude and longitude are = half(range of values) + grid discretization
errlat = (max(testlat(ilats)) - min(testlat(ilats)))/2 + dlat;
errlon = (max(testlon(ilons)) - min(testlon(ilons)))/2 + dlon;
errlat = max(errlat,4*dlat);            % minimum value
errlon = max(errlon,4*dlon);
 
% get error ellipse using eigenvectors/eigenvalues ....................................
bestlat = (max(testlat(ilats)) + min(testlat(ilats)))/2;    % center of the ellipse
bestlon = (max(testlon(ilons)) + min(testlon(ilons)))/2;
x1 = testlon(ilons) - bestlon;
x2 = testlat(ilats) - bestlat;
% convert from degrees to km
y = 111.111 * [x1(:)*cosd(bestlat) x2(:)];
A = y'*y/length(ind);
[v,d]=eig(A);
% d are eigenvalues and columns of v are corresponding eigenvectors
d = diag(d);
[dum,ieig]=max(d);
% axis of ellipse is the eigenvector corresponding to the largest eigenvalue
ellipsang = atan(v(1,ieig)/v(2,ieig))*180/pi;
maxis = 2*sqrt(sort(d));            % double standard deviation = 95% confidence limits
minaxis = min(111.11*[dlat dlon*cosd(bestlat)]);
maxis = max(maxis,minaxis);
                                                         
% compute the slope and origin time for best point  (= mid point)
% slope ( = slowness)
[kmdist,az] = distance(slats,slons,bestlat,bestlon,SPHEROID);

% estimate of slope and origin time - L1 misfit, ideally
Xmat = [ones(length(kmdist),1) kmdist(:)];
if (ntriad < 8)
% get a least squares solution as initial solution to L1 norm
    xsol = regress(sigtimes(:),Xmat);
else
% get a robust estimate of slope and origin time
   [xsol] = robustfit(kmdist,sigtimes);
% The time estimate is off if there's more than one phase
% allow for 2 at most (i.e. P and S phases for seismic)
% XX (there is probably a better way to separate populations than this)
% in future, throw out very bad celerities
   celer = kmdist(:)./(sigtimes(:)-xsol(1));
   celer = max(celer,0);  % celerity must be >0
   [iMain,iS,iP] = findPops(celer);

   nM = length(iMain);
% resolve 
   if (nM < ntriad & nM > 8)
      [xsol] = robustfit(kmdist(iMain),sigtimes(iMain));
   end
end
besttime = round(xsol(1)); vslow = xsol(2);
                                                         
return

                                                         
% comment out the return to debug (via plots) -------------------------------------
                                                
color=jet;color(end,:) = 0.9*[1 1 1];

minlat = min([bestlat min(trilat(iii))])-5;
maxlat = max([bestlat max(trilat(iii))])+5;
minlon = min([bestlon min(trilon(iii))])-5;
maxlon = max([bestlon max(trilon(iii))])+5;
                                                         
% do some plots
figure(1),clf
imagesc(testlon,testlat,L1misfit'),axis xy,colorbar('vert')
colormap(color),hold on,plot(bestlon,bestlat,'rs','MarkerFaceColor','r')
plot(testlon(ilons),testlat(ilats),'r.')
plot(trilon(iii),trilat(iii),'go'),,    % plot(trilon,trilat,'k.'),
title('azimuth misfit function and array locations')
load coast, plot(long,lat,'k')
% ylim([minlat maxlat]),xlim([minlon maxlon])
        
ellipsang
maxis
        
figure(13),clf,plot(kmdist,sigtimes/3600,'ko'),hold on
xline = [min(kmdist) max(kmdist)];
tline = besttime + vslow*xline;
plot(xline,tline/3600,'r')
xlabel('Range (km)','FontName','Comic')
ylabel('Time of day (hr)')
title('Time vs Range for optimal location','FontName','Comic')
%         print ('TimeVsRange','-djpeg')
%figure(2),clf,plot(sigtimes,sazmth,'ko')

% plot arrows
srcaz = Csetminmax(sazmth+180,0,360);
px = 0.5*cos(srcaz(:)*pi/180);
py = 0.5*sin(srcaz(:)*pi/180);
x = slats; y = slons;
x=x(:);y=y(:);
figure(4),clf,quiver(y,x,py,px,'r'); hold on
trange = max(sigtimes) - min(sigtimes) ;      ;
% scatter(y,x,40,(sigtimes-min(sigtimes))/trange,'filled')
plot(long,lat,'k')
% colorbar('vert'),colormap(flipud(jet))
hold on,plot(bestlon,bestlat,'rs','MarkerFaceColor','r')
ylim([minlat maxlat]),xlim([minlon maxlon])
title('azimuths'),grid
 
disp('in grid_Search')
% load chirp
% sound(y,Fs)
keyboard
