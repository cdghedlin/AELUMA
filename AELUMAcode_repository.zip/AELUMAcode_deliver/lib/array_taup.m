% NOTES: the tau-p method is very slow for large arrays, not too bad for smaller ones
%
% array_taup:
%       finds best plane wave azimuth & velocity for an array at 1 frequency
%
% input:
%	dataseg - data in a given time window (nt X nsites)
%	fsenv - sampling rate
%	XR - [nseries by 2] matrix of receiver locations
%   Amat - relative positions between all pairs
%   staPairs - info on all pairs
%   mwin - number of windows
%   ibeg, iend - beginning and endpoints of each windows
%   maxlagn - maximum lag dependent upon array size
%   vmin - minimum possible phase velocity across array
%   whether or not envelopes are used
%
% output: 
%	plvec - plane wave velocities	(1 * time points)
%	azvec - plane wave azimuths		(1 * time points)
%   xcor - average x-correlation for best plane wave    (1 * time points)
%	fitvec - (fractional) time fit for best plane wave	(1 * time points)
%   ttvec,ampvec - time (seconds) and amplitude (SNR) of maximum beam for each window
%
%   defaults are returned if too few delay times are consistent

function [plvec,azvec,xcor,fitvec,ttvec,ampvec] = array_taupNew(filtdat,fsamp,XR,Amat,staPairs,mwin,ibeg,iend,vmin,ifenv);

[xlen,msta] = size(filtdat');
nrow = sum(1:msta-1);
tdelmax = staPairs(:,3)/vmin/1000;   % maximum possible time delay in seconds

minPairs = max(3,ceil(nrow/2));         % at least half the pairs must fit
minSta = max(3,msta-2);    % maximum two stations are allowed to drop out
maxlag = ceil(fsamp*staPairs(:,3)/vmin/1000);   % variable with station separation
                   
fdet = 1;                   % compute amplitude measure within beamformer
options = optimoptions('fminunc','Display','off');      % suppress output
   
% *************************************************************************

% for tau-p method, see Chapter_9.pdf (on Mac) Array Processing from
% Routine data Processing in Earthquake Seismology
% for more see NMSOP.pdf (Manual of Seismological Observatory Practice)

% ~~~~~~~~~~~~~~~~ initialize values ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

plvec = -10+zeros(mwin,1); azvec = 380+zeros(mwin,1);
xcor = zeros(mwin,1); fitvec = ones(mwin,1);
ttvec = -1+zeros(mwin,1); ampvec=zeros(mwin,1);
                   
indB = find(maxlag> 2); nrowB = length(indB);
AmatB = Amat(indB,:);
psolver = inv(AmatB'*AmatB)*AmatB';

% .....................................................................
%   look at SNR, only process events with sufficient signal
% .....................................................................
 
% compute amplitude measure. Only analyse those where
% value is well above the median. This is only useful if we're
% looking for impulsive events - above noise.  To look for signals
% embedded within noise comment out this section and set ifamp==1
if (ifenv)                          % for envelopes
    totdat = sum(filtdat)/msta;
    twostd = 2*std(totdat);
    for jwin = 1:mwin
        nr1 = ibeg(jwin); nr2 = iend(jwin);
        ifamp(jwin) = max(totdat(nr1:nr2)) > twostd;
    end     % end loop over time windows for an array
%    figure(11),clf,plot(totdat),hold on,plot([1 xlen],twostd*[1 1],'r','LineWidth',1)
              
else
% need a denominator because noise levels change during the day
    totdat = sum(filtdat.*filtdat);
    beamscale = zeros(mwin,1); bmdenom = zeros(mwin,1);
    for jwin = 1:mwin
        nr1 = ibeg(jwin); nr2 = iend(jwin);
        beamscale(jwin) = sum(totdat(nr1:nr2))/msta;
    end     % end loop over time windows for an array
    beamscale = log10(beamscale);
              
% instead of smoothing, find median value for each nsmhr windows
% where nsmhr is about the number of windows per hour, ie moving median
    nsmhr = floor(mwin/(2*24));
    for jwin = nsmhr+1:mwin-nsmhr
        bmdenom(jwin) = median(beamscale(jwin-nsmhr:jwin+nsmhr));
    end
    bmdenom(1:nsmhr) = bmdenom(nsmhr+1);
    bmdenom(mwin-nsmhr:mwin) = bmdenom(mwin-nsmhr);

    for jwin = 1:mwin               % looking for SNR > 1.6
        ifamp(jwin) = beamscale(jwin) > 0.2+bmdenom(jwin);
    end
    
    figure(11),clf,plot([1:mwin]/mwin*24,beamscale),hold on
    plot(24*[1:mwin]/mwin,0.2+bmdenom,'r','LineWidth',1)
    xlim([0 24])
    pause(0.001)
 
end
lenamp = sum(ifamp);

% .....................................................................
            
Nmax = 1;           % do only 1 iteration
                   
%  loop over each time window at a given array
for jwin = 1:mwin
    if (ifamp(jwin)==0); continue; end
              
    nr1 = ibeg(jwin); nr2 = iend(jwin);
    xseglen = nr2-nr1+1;
    dataseg = filtdat(:,nr1:nr2)';          % switch order to (nt X msta)
    [tau,xmag] = NxcorrTest(dataseg,fsamp,maxlag,nrow);
                   
% compute solution using all pairs (in indB)
    tauB = tau(indB);
    psolo2 = psolver*tauB;          % the least squares misfit
% get th L1 misfit
    V = @(x) norm(tauB-AmatB*x,1);        % to get the L1 misfit XX put this outside of loop?
    psolo = fminunc(V,psolo2,options);        % use least squares as the starting point
    tmisfito = abs(AmatB*psolo-tauB);
    taufitave = mean(tmisfito)/mean(abs(tauB));
              
% initial solution
    fitvec(jwin) = taufitave;
    pxo = psolo(1);  pyo=psolo(2);
    thetao = atan2(pxo,pyo)*180/pi;
    azvec(jwin) = Csetminmax(thetao,0,360);
    plvec(jwin) = sqrt(1/(pxo*pxo+pyo*pyo));
    xcor(jwin) = mean(xmag(indB));
    ista = [1:msta];
                   
    if (taufitave > 0.1)            % look for better solution by throwing out bad pairs
        for jj = 1:Nmax             % only do 1 iteration
            tcut = 2.0*median(tmisfito);
            ikeep = find(tmisfito<tcut);
            lenkeep = length(ikeep);
            if (lenkeep < minPairs)         % too few time pairs left, use previous solution
                break
            end
            Amatk = AmatB(ikeep,:);
            tauk = tauB(ikeep);
            psolk2 = inv(Amatk'*Amatk)*Amatk'*tauk;
            V = @(x) norm(tauk-Amatk*x,1);        % to get the L1 misfit rather than least squares
            psolk = fminunc(V,psolk2,options);        % use least squares as the starting point
            taufitk = Amatk*psolk;
            tmisfitk = abs(taufitk-tauk);
            taufitavek = mean(tmisfitk)/mean(abs(tauk));
                         
            if (taufitavek < taufitave)     % only use new solution if it is better
                pxo = psolk(1);  pyo=psolk(2);
                thetao = atan2(pxo,pyo)*180/pi;
                azvec(jwin) = Csetminmax(thetao,0,360);
                plvec(jwin) = sqrt(1/(pxo*pxo+pyo*pyo));
                ista = unique([staPairs(ikeep,1)' staPairs(ikeep,2)']);
                fitvec(jwin) = taufitavek; xcor(jwin) = mean(xmag(ikeep));
            end
                                 
        end         % end of Nmax iteration loop
    end         % end of if statement

% do beamform
% obeam is wrt to the center of the array (keep center constant for all sta combos XXXX)
    [obeam,fval]=beamformF(dataseg(:,ista),fsamp,azvec(jwin),plvec(jwin),XR,fdet);
    [omax,itt] = max(abs(obeam));
% get arrival time and scaled amplitude
    ttvec(jwin) = (nr1+itt-1)/fsamp;      % time in seconds
    ampvec(jwin) = fval;     % shows how well signals line up
                        
end          % end loop over time windows for an array
                        
% [XXXX NOTES: could also get error in velocity and azimuth by taking the differences
% in values between L2 and L1 norm solutions
    

return

                                
% ----------------------------------------------------------------------------------
% to debug, comment out end and return lines above
% plot a data figure to show how this works in practice
% plot a window for which    fitvec is low  (< 0.1)
%                            xcor is not great (between 0.35 - 0.5)
%                            ampvec > 6
% this shows an example of a window where we get a good result (fitvec)
% but data are noisy (xcor is only OK)
% for arrays, must have a VERY lax constraint on plvel
 
ttscale = 24*[1:mwin]/mwin;
igood = find(xcor>0.5 & fitvec<0.8 & ampvec>1);length(igood)
figure(1),clf,subplot(6,1,1),plot(ttscale,plvec(1:mwin)/1000,'k.')
            hold on,plot(ttscale(igood),plvec(igood)/1000,'ro')
            grid,ylabel('V (km/s)'),ylim([0 16]),xlim([0 24])
    subplot(6,1,2),plot(ttscale,xcor,'ko'),grid,ylabel('Xcor')
            hold on,plot(ttscale(igood),xcor(igood),'ro'),xlim([0 24])
    subplot(6,1,3),plot(ttscale,azvec,'k.'),grid, ylabel('azimuth')
            hold on,plot(ttscale(igood),azvec(igood),'ro'),xlim([0 24])
    subplot(6,1,4),plot(ttscale,ampvec,'k.'),grid,ylabel('ampvec')
            hold on,plot(ttscale(igood),ampvec(igood),'ro'),xlim([0 24])
    subplot(6,1,5),plot(ttscale,fitvec,'k.'),grid,ylabel('fitvec')
            hold on,plot(ttscale(igood),fitvec(igood),'ro'),xlim([0 24])
    subplot(6,1,6),plot(ttscale,beamscale,'k'),grid,ylabel('beamscale')
            hold on,plot(ttscale,bmdenom,'r'),
            plot(ttscale(igood),beamscale(igood),'go'),xlim([0 24])
                         
figure(2),clf,
    subplot(2,1,1),plot(fitvec,ampvec,'ko'),hold on
    plot(fitvec(igood),ampvec(igood),'ro')
    subplot(2,1,2),plot(beamscale(igood)-bmdenom(igood))
    disp('line 210 in array_taupNew')
    
    keyboard

return
                         
        if (msta ==13 & ttvec(jwin)/3600>5.9 & fitvec(jwin) < 0.8 & xcor(jwin) > 0.3)
            [jwin nrowB]
            [ttvec(jwin)/3600 ampvec(jwin) fitvec(jwin) xcor(jwin)  plvel/1000 plazm]
            tsave = [nr1:nr2]/fsamp/60;
                                
            figure(3),clf,axes('position',[0.1 0.34 0.48 0.4])
            scale = 2*max(max(abs(dataseg)));
            for kk = 1:msta
                isgood = ismember(kk,ista);
                data2 = dataseg(:,kk)/scale;
                if (isgood)
                    plot(tsave,kk+data2,'k','LineWidth',1),hold on
                else
                    plot(tsave,kk+data2,'Color',0.4*[1 1 1]),hold on
                end
            end
            ylim([0 msta+1]), ylabel('Station Number')
            xlim([tsave(1) tsave(end)]),
            grid
            h=gca;set(h,'XTickLabel',[]);

            axes('position',[0.1 0.1 0.48 0.2])
            plot(tsave,obeam/scale,'k','LineWidth',1), grid, hold on
            xlim([tsave(1) tsave(end)]),
            xlabel('Time of Day (min)'),ylabel('Beam')
            orient portrait
            print('ArraySum','-djpeg')
                                
            figure(4),clf,axes('position',[0.1 0.2 0.48 0.6])
            plot(tau,'-ko'),hold on,plot(indB,taufitB,'-rs')
            plot(indB,tau(indB),'ko','MarkerFaceColor',0.2*[1 1 1])
            title(['fitvec(',int2str(jwin),') = ',num2str(fitvec(jwin))])
                                
            disp('testing in array_taup, line 198')
            keyboard
                                
                                
        end
%end
%return
