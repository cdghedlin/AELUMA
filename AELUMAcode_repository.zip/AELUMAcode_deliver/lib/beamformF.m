% beamform:
%       make a beam-formed waveform for the given azimuth & velocity
%       also do local residuals
%
% input:
%	data - data in a given time window (nt X nsites)
%	fsamp - sample rate for data
%	plazm,plvel - input plane azimuth (degrees) and velocity
%	XR - locations of stations wrt center of array
%   fstat - if the f detector is being used
% output:
%	obeam - output beamed waveform (=0 if nbeg/nend outside limits)
%   fvalue - value of f detector (see Blandford 1974 or Arrowsmith etal, 2009)
%
function [obeam,fvalue]=beamform(data,fsamp,plazm,plvel,XR,fstat);

[xlen,nsites] = size(data);

slowvel = 1./plvel;
slowvec = slowvel*[sind(plazm) cosd(plazm)];
rtdel = -1*round(fsamp*(XR*slowvec'));         % delay times in number of samples
% multiply by -1 to align since plazm is direction to source
% if tau had opposite sign, would not have to do this
   
% compute shifted data

datshift = zeros(size(data));
%figure(1),clf, scale = 1/max(abs(data(:)));
for ns = 1:nsites
    if (rtdel(ns)>=0)
        datshift(1:xlen-rtdel(ns),ns) = data(1+rtdel(ns):xlen,ns);;
    else
        datshift(1-rtdel(ns):xlen,ns) = data(1:xlen+rtdel(ns),ns);
    end
%    plot(scale*datshift(:,ns)+ns,'k'),hold on,% plot(scale*data(:,ns)+ns,'r')
end
obeam = sum(datshift'); obeam = obeam(:)/nsites;
% plot(obeam*scale+ns+1,'r','LineWidth',1)
            
%    disp('line 40 in beamformF'),  keyboard
            
if (~fstat)
    fvalue = [];
    return
else            % compute the residual misfit for each trace
    resid = zeros(size(data'));
%    figure(2),clf
    for ns = 1:nsites
       resid(ns,:) = datshift(:,ns)-obeam;
%       plot(scale*resid(ns,:)+ns,'k'),hold on,plot(ns+scale*datshift(:,ns),'r')
    end
%    plot(scale*obeam+ns,'g')
% use definition of F value as in Arrowsmith etal, 2009
    residsq = sum(resid.*resid);        % sum over stations
    obeamsq = (nsites*obeam).^2;
    fvalue = (nsites - 1)*sum(obeamsq)/(eps+nsites*sum(residsq));
    return
 end

                    
