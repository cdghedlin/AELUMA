% FIT			least-sqaures fit to a straight line
% function [a,b,siga,sigb,chi2,misfit] = myfit2(x,y,sig,mwt);
%
%	input:
%		x,y - set of data points
%		sig - error in y
%		mwt - if mwt=0, then standard deviations are unavailable,
%	output:
%		a - y-value at x=0
%		b - slope
%		siga,sigb - errors in a and b
%		chi2  - sigma squared
%		misfit : vector of errors for each point
% translation of subroutine fit, p659-660 in Numerical recipes
function [a,b,siga,sigb,chi2,misfit] = myfit2(x,y,sig,mwt);

ndata=length(x);

if mwt~0;
    wt=1./(sig.*sig);
    ss=sum(wt);
    sx=sum(x.*wt);
    sy=sum(y.*wt);
else
    sx=sum(x);sy=sum(y);
    ss=ndata;
end
sxoss=sx/ss;
if mwt~0;
    t=(x-sxoss)./sig;
    st2=sum(t.*t);
    b=sum(t.*y./sig);
else
    t=x-sxoss;
    st2=sum(t.*t);
    b=sum(t.*y);
end
b=b/st2;
a=(sy-sx*b)/ss; 
siga=sqrt((1+sx*sx/(ss*st2))/ss);
sigb=sqrt(1./st2);
%
if mwt==0;
   misfit=(y-a-b*x);
   chi2 = sum(misfit.*misfit);
   sigdat=sqrt(chi2/(ndata-2));
   siga=siga*sigdat;
   sigb=sigb*sigdat;
else
   misfit=(y-a-b*x)./sig;
   chi2 = sum(misfit.*misfit);
end

