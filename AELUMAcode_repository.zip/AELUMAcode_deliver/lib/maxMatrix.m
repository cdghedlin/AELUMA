% gets row and column index of 2D matrix maximum
%       only gets the first maximum value
%
%   input
%       A: 2D matrix
%       value; the value to find in that matrix
%       operation: (1 = maximum), (2 = minimum)
%   output
%       value
%       row
%       column
%
%   usage: [value,row,column] = maxMatrix(A,operation);

function [value,row,column] = maxMatrix(A,operation);
if (operation == 1)
    [y,in] = max(A);
    [value,column] = max(y);
    [~,row] = max(A(:,column));
elseif (operation == 2)
    [y,in] = min(A);
    [value,column] = min(y);
    [~,row] = min(A(:,column));
else
    disp('bad operation in maxMatrix')
end
