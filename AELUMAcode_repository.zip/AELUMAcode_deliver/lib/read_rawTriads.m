% read_rawTriads:
%       reads in and does some culling of the triad detections
%       returns the detections in vector form
%
% PROGRAM NOTES:
%       1) read in detections; remove if criteria are not satisfied
%           (snr cutoff, consistency cutoff, phase velocity limits &
%           amplitudes)
%       2) compute array centers
%       3) associate each detection with an array
%       4) convert detections to vectors of points
%
% input:
%	fid : file number to read from
%   xccut : lowest allowable cross correlation  used in conjunction with
%	fcut : lowest allowable F-val
%	Tconscut : fractional consistency cutoff
%   vphmin,vphmax : phase velocity limits in km/s
%   Afit : allowable misfit in azimuth (degrees)
%	hr1, hr2 - read in data from hr1 - hr2
%
% output: 
%	detectv : ndetect x 10 matrix of array detections, rows =
%       trilat,trilon - center of triad
%		ttsig,ampsig  - arrival time and amplitude of beamed signal
%		xcorr - average cross-correlation between all station pairs
%		phasevel,azmth - phase velocity and azimuth solution for array
%       taufit - average fractional time consistency
%       ntriad - triad number at which detection is made
%       midf  - frequency band number
%	stalat,stalons - station latitudes and logitudes
%   indtri - matrix giving the station numbers within each triad
%   ntri - number of triads
%
%
function [detectv,stalats,stalons,indtri,ntri] = read_rawTriads(fid,xccut,fcut,Tconscut,vphmin,vphmax,Afit,hr1,hr2);

% set a few defaults

veldefault = -1; azdefault = 380;		% default phase velocity & azimuth
xcdefault = 0; taudefault = 1;		    % default xcorr and fractional time misfit
ttbeamdef = -60; abeamdef = 0;         % default arrival times and SNR amplitudes
SPHEROID = referenceEllipsoid('wgs84', 'km');

% *************************************************************************
%	Section 1a: read in part of detection file dealing with network
%              configuration
% *************************************************************************

alldata = fread(fid,'real*4'); fclose(fid);
nsta = alldata(1);  nfin = 1;							   % # stations
    
stalats = alldata(nfin+1:nfin+nsta); nfin=nfin+nsta;       % station lats
stalons = alldata(nfin+1:nfin+nsta); nfin=nfin+nsta;       % station longs
ntri = alldata(nfin+1); nfin=nfin+1;                       % # triangles
dum = alldata(nfin+1:nfin+3*ntri);    nfin=nfin+3*ntri;    % dummy, ignore
indtri=reshape(dum,ntri,3);                         % station #s, each triad
triadR = alldata(nfin+1:nfin+2);    nfin=nfin+2;           % [rtmin rtmax]
triadA = alldata(nfin+1:nfin+2);    nfin=nfin+2;           % [minang maxang]
numf = alldata(nfin+1);    nfin=nfin+1;

fprintf('\t %d ntri, %d stations for this day \n',ntri,nsta)

% ----------------------------------------------------------
%   Section 1b: compute triad centers and define region
% ----------------------------------------------------------

for jj = 1:ntri
    trilats=stalats(indtri(jj,:));
    trilons=stalons(indtri(jj,:));
    clon(jj)=mean(trilons);    clat(jj)=mean(trilats);            % centers
end

lat1 = floor(min(stalats)); lat2 = ceil(max(stalats));
lon1 = floor(min(stalons)); lon2 = ceil(max(stalons));

% *************************************************************************
%    Section 2: read in part of detection file dealing with frequency
%              dependent detections
% *************************************************************************

ttsigf = []; trilatf = []; trilonf = []; ampsigf = []; xcorrf = [];
phasevelf = []; azmthf = []; taufcloudf = []; ntriadf = []; midf = [];

% frequency dependent information
for kf = 1:numf
    fbands = alldata(nfin+1:nfin+2);	nfin=nfin+2;
    tsmooth = alldata(nfin+1:nfin+2);   nfin=nfin+2;         % [tsta tlta]
    twinjump = alldata(nfin+1:nfin+2);  nfin=nfin+2;         % [twin tjump]
    tlen = alldata(nfin+1);				nfin=nfin+1;         % # windows in the day
    itriad = repmat([1:ntri]',1,tlen);  % initialize the triad numbering matrix

    dum = alldata(nfin+1:nfin+tlen*ntri);	nfin=nfin+tlen*ntri;
    velsave = reshape(dum,ntri,tlen);                   % phase velocities in m/s
    dum = alldata(nfin+1:nfin+tlen*ntri);	nfin=nfin+tlen*ntri;
    azsave = reshape(dum,ntri,tlen);
    dum = alldata(nfin+1:nfin+tlen*ntri);	nfin=nfin+tlen*ntri;
    xcsave = reshape(dum,ntri,tlen);
    dum = alldata(nfin+1:nfin+tlen*ntri);	nfin=nfin+tlen*ntri;
    taufit = reshape(dum,ntri,tlen);        % (fitvec)

% arrival times & amplitudes of the beam-formed envelope
% the arrival time is with respect to the centroid location for each triad
    dum = alldata(nfin+1:nfin+tlen*ntri);	nfin=nfin+tlen*ntri;
    ttbeam = reshape(dum,ntri,tlen);
    dum = alldata(nfin+1:nfin+tlen*ntri);	nfin=nfin+tlen*ntri;
    ampbeam = reshape(dum,ntri,tlen);

% -------------------------------------------------------------------------
%   Section 2b: at each frequency dump values that don't meet the cutoffs
% -------------------------------------------------------------------------

    ind = find(ttbeam(:)<=hr1*3600 | ttbeam(:)>=hr2*3600 | ampbeam(:)<fcut | xcsave(:)<xccut | taufit(:)>Tconscut | velsave(:)>vphmax*1000 | velsave(:)<vphmin*1000 );
    ndetect = tlen*ntri-length(ind);
    velsave(ind) = veldefault; azsave(ind) = azdefault;
    xcsave(ind) = xcdefault;  taufit(ind) = taudefault;
    ttbeam(ind) = ttbeamdef; ampbeam(ind) = abeamdef;

    fprintf('\t %d windows of length %d s \n',tlen, twinjump(1))
    fprintf('\t %d detections at frequency %d\n',ndetect,kf)
    if (ndetect==0) npick(kf) = 0; continue; end
                        
% -------------------------------------------------------------------------
%   Section 2c: convert detections at this frequency to vectors of points
% -------------------------------------------------------------------------
    icl = find(ttbeam>0);
    npick(kf) = length(icl);
    if (length(icl)==0) continue;  end

    ntriad = itriad(icl);       % save triad number
    trilat = clat(ntriad);
    trilon = clon(ntriad);
    ttsig = ttbeam(icl); ampsig = ampbeam(icl);
    xcorr = xcsave(icl); taufcloud = taufit(icl);
    phasevel = velsave(icl); azmth = azsave(icl);
    fmid = kf + zeros(npick(kf),1);         % number, not mean(fbands)
                    
    ttsigf = [ttsigf(:); ttsig(:)];
    trilatf = [trilatf(:); trilat(:)]; trilonf = [trilonf(:); trilon(:)];
    ampsigf = [ampsigf; ampsig(:)]; xcorrf = [xcorrf; xcorr(:)];
    phasevelf =[phasevelf; phasevel(:)]; azmthf=[azmthf; azmth(:)];
    taufcloudf = [taufcloudf; taufcloud(:)];
    ntriadf = [ntriadf; ntriad(:)]; midf = [midf; fmid(:)];                        
% -------------------------------------------------------------------------

end                 % end loop over frequencies for kf = 1:numf
                    
clear alldata dum;
ndetect = sum(npick);
fprintf('\n %d total detections over %d frequencies \n',ndetect,numf)
                    
if (ndetect==0) detectv=[]; return; end
  
% *************************************************************************
%    Section 3: only save families of detections at each triad
% *************************************************************************
                    
% to define a family there must be several detections with
% azimuths and arrival times that agree to within Afit and tcut
nfam = 3;       % number to define a family
                    
tcut = tsmooth(1);     % smoothing length
if tcut == 0
    tcut = twinjump(2)/2;
end
[numdet,numdet2,numdet3] = deal(zeros(ntri,1));
for jj = 1:ntri
    ii = find(ntriadf == jj); lii = length(ii);
    numdet(jj) = lii;
    if (lii == 0) continue; end
% get all arrival times and azimuths at the triad
    ttsigtri = ttsigf(ii);
    aztri = azmthf(ii);
    if (numdet(jj) < nfam) % set the arrival time and azimuth to default values
        ttsigf(ii) = ttbeamdef;
%        azmthf(ii) = azdefault;
    end
    iflag = zeros(lii,1);     % set to one for a good point
    for jj2 = 1:lii      % check for matching time and azimuth values
% values with nearly matching times and azimuths
        azdiff = abs(Csetminmax(aztri(jj2)-aztri,-180,180));
        itt = find(  abs(ttsigtri(jj2)-ttsigtri) < tcut & azdiff < Afit/2 );
        litt = length(itt);
        if (litt >=nfam);
            iflag(itt) = 1;
        end
    end
    numdet2(jj) = sum(iflag);
    idump = find(iflag==0);
    ttsigf(ii(idump)) = ttbeamdef;
end

ndetect = sum(numdet2);
fprintf('\n %d remain after removal of non-family detections \n',ndetect)
if (ndetect==0) detectv=[]; return; end

% remove detections that do not belong to a family
icl = find(ttsigf>0);
ttsigf = ttsigf(icl);
trilatf = trilatf(icl); trilonf = trilonf(icl);
ampsigf = ampsigf(icl); xcorrf = xcorrf(icl);
phasevelf = phasevelf(icl); azmthf = azmthf(icl);
taufcloudf = taufcloudf(icl); ntriadf = ntriadf(icl);
midf = midf(icl);
                    
% now represent each family by 1 member (allow 1 per frequency)
% to vastly reduce the number of detections (by a factor of 3 to 4)
for jj = 1:ntri
    if (numdet2(jj) == 0); continue; end
    ii = find(ntriadf == jj); lii = length(ii);
    ttsigtri = ttsigf(ii);
    aztri = azmthf(ii);
    midftri = midf(ii);
% if more than one member of family at a given frequency, choose the best based on
%  best Xcorrf, (instead of highest amplitude or lowest taucloudf (time consistency))
    iflag = zeros(lii,1);     % set to one for a good point
    for jj2 = 1:lii      % check for matching time and azimuth values
        azdiff = abs(Csetminmax(aztri(jj2)-aztri,-180,180));
% save a value for each frequency
        for jjf = 1:numf
            itt = find( (abs(ttsigtri(jj2)-ttsigtri) < tcut) & (azdiff < Afit/2) & (midftri==jjf) );
            litt = length(itt);
            [dum,ibest] = max(xcorrf(ii(itt)));
            iflag(itt(ibest)) = 1;
        end
    end             % end of jj2 loop
    idump = find(iflag==0);
    ttsigf(ii(idump)) = ttbeamdef;
    numdet3(jj) = sum(iflag);
end
 
ndetect = sum(numdet3);
fprintf('\t %d remain after combining family detections \n',ndetect)
if (ndetect==0) detectv=[]; return; end
                    
icl = find(ttsigf>0);
ttsigf = ttsigf(icl);
trilatf = trilatf(icl); trilonf = trilonf(icl);
ampsigf = ampsigf(icl); xcorrf = xcorrf(icl);
phasevelf = phasevelf(icl); azmthf = azmthf(icl);
taufcloudf = taufcloudf(icl); ntriadf = ntriadf(icl);
midf = midf(icl);
                    
% *************************************************************************
%    Section 4: now sort by time
% *************************************************************************
                    
[ttsigf,itsort] = sort(ttsigf);
trilatf = trilatf(itsort); trilonf = trilonf(itsort);
ampsigf = ampsigf(itsort); xcorrf = xcorrf(itsort);
phasevelf = phasevelf(itsort); azmthf = azmthf(itsort);
taufcloudf = taufcloudf(itsort); ntriadf = ntriadf(itsort);
midf = midf(itsort);
							 
% *************************************************************************
%	Section 5: return detection info as matrix
% *************************************************************************

detectv = zeros(10,ndetect);
detectv(1,:) = trilatf; detectv(2,:) = trilonf;
detectv(3,:) = ttsigf; detectv(4,:) = ampsigf;
detectv(5,:) = xcorrf; detectv(6,:) = phasevelf;
detectv(7,:) = azmthf; detectv(8,:) = taufcloudf;
detectv(9,:) = ntriadf; detectv(10,:) = midf;
