% beamform:
%       make a beam-formed waveform for the given azimuth & velocity
%
% input:
%	data - data in a given time window (nt X nsites)
%	fsamp - sample rate for data
%	plazm,plvel - input plane azimuth (degrees) and velocity
%	XR - locations of stations wrt center of array
% output:
%	obeam - output beamed waveform (=0 if nbeg/nend outside limits)
%
function [obeam]=beamform(data,fsamp,plazm,plvel,XR);

[xlen,nsites] = size(data);

slowvel = 1./plvel;
slowvec = slowvel*[sind(plazm) cosd(plazm)];
rtdel = -1*round(fsamp*(XR*slowvec'));         % delay times in number of samples
% multiply by -1 to align since plazm is direction to source
% if tau had opposite sign, would not have to do this
                          
obeam = zeros(xlen,1);
for ns = 1:nsites
    if (rtdel(ns)>=0)
        obeam(1:xlen-rtdel(ns)) = obeam(1:xlen-rtdel(ns))+data(1+rtdel(ns):xlen,ns);
    else
        obeam(1-rtdel(ns):xlen) = obeam(1-rtdel(ns):xlen)+data(1:xlen+rtdel(ns),ns);
    end
end
