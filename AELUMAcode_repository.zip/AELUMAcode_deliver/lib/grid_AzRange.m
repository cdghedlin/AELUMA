%  AELUMA public bundle
%
% grid_AzRange:
%       find the distance and azimuth grids for the count_group routine
%       the matrix distgrid is the matrix of distances from ALL triad centers to gridpoints
%       the size of distgrid is (nlat*nlon,length(trilat))
%       also find the max distance that any detection may be (for any gridpoint)
%
% input:
%	trilat,trilon : vectors of triad detection latitudes & longitudes
%	testlat,testlon : vectors defining search grid
%   mincluster - the minimum number of detections needed to define a cluster
%
% output:
%   distgrid, azgrid - matrix of distances&azimuths from triad centers to gridpoints
%   kmcutoff - maximum distance of nearest detection
%   ntri - number of unique triads/arrays
%
function [distgrid,azgrid,kmcutoff,ntri] = grid_AzRange(trilat,trilon,testlat,testlon,mincluster)

SPHEROID = referenceEllipsoid('wgs84', 'km');
nlon=length(testlon); nlat=length(testlat);

[distgrid,azgrid] = deal(zeros(nlat*nlon,length(trilat)));

% this computation would be redone over and over, for the same triad location
% since many trilat/trilon repeat (fixed using unique command)
y=[trilat;trilon]';		%'
[c,ia,ic]=unique(y,'rows');
kmcutoff = 20000 + zeros(nlat*nlon,1);
ntri = length(ia);
ncutoff = max(round(ntri/10),mincluster);    % at least 1 detection must be within nearest ncutoff triads

icount = 0;
for ilat = 1:nlat
	for ilon = 1:nlon
        icount = icount+1;
		[ukmdist,az] = distance(c(:,1),c(:,2),testlat(ilat),testlon(ilon),SPHEROID);
        sortdist = sort(ukmdist);
        kmcutoff(icount) = sortdist(ncutoff);
		az=az(ic);kmdist=ukmdist(ic);        % expanded out to repeating triad locations
        distgrid(icount,:) = kmdist; 
		azgrid(icount,:) = az;
	end                                 % end loop over longitude
end                                     % end loop over latitude

return

% to trouble-shoot, comment out the return and map the cutoff distance
dum = reshape(kmcutoff,nlon,nlat);
figure(2),clf,imagesc(testlon,testlat,dum'),axis xy,colormap(jet),colorbar('vert')
hold on,plot(trilon,trilat,'w.')
load coast, plot(long,lat,'w','LineWidth',2)
round([min(kmcutoff) max(kmcutoff)])

disp('see map of kmcutoff')
keyboard
