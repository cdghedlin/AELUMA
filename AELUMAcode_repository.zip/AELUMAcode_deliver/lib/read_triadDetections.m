% *****************************************************************************
%    Section 2: read in triad detections for this day
% *****************************************************************************

fprintf('\n---> read solutions from output file created in Triad_detections \n\n');
fnamejd=[Dir,'triadsRaw_',int2str(jdmonth),'_',int2str(iyr),'_flag',int2str(triadflag),'.out'];
fprintf('[INFO] detection file: %s\n', fnamejd);
fid=fopen(fnamejd,'r');
if fid==-1
    fprintf('[WARN] missing detections for day %03d\n',jdmonth);
    detectv = []; stalats1 = []; stalons1 = [];
    indtri1 = []; ntri1 = 0;
else
    [detectv,stalats1,stalons1,indtri1,ntri1] = read_rawTriads(fid,triadxccut,ampcut,triadTconscut,vphmin,vphmax,Afit,hr1,hr2);
end
hr22 = 0;

% *****************************************************************************
%	Section 2b: read a few hours for the next day, if available, & merge
% *****************************************************************************
    
if (hr2==24 & iflag==1)
    fprintf('\n---> section 3 - read a few hours for the next day, if available, & merge\n\n');
    fnamejd=[Dir,'triadsRaw_',int2str(jdmonth+1),'_',int2str(iyr),'_flag',int2str(triadflag),'.out']
    fprintf('[INFO] detection file for the next day: %s\n', fnamejd);
    fid=fopen(fnamejd,'r');
    if fid==-1
        fprintf('[WARN] next day %03d detections are missing\n',jdmonth+1)
        stalats = stalats1; stalons = stalons1;
        indtri = indtri1; ntri2 = 0;
    else
% read in detections for the beginning of the next day for a signal crossing the entire network
% this is needed to identify signals with a start time at about 23:59:59
        hr12 = 0; hr22 = txnetwork;        %(hr22 is time needed for signal to cross network for 2nd day)
        [detectv2,stalats2,stalons2,indtri2,ntri2] = read_rawTriads(fid,triadxccut,ampcut,triadTconscut,vphmin,vphmax,Afit,hr12,hr22);
        if ((ntri2 > 0) & (~isempty(detectv2)))
            detectv2(3,:) = detectv2(3,:)+24*3600;	% add 24 hours to next day
            detectv2(9,:) = detectv2(9,:)+ntri1;	% renumber triads in 2nd part
            detectv = [detectv detectv2];
            stalats=[stalats1;stalats2]; stalons=[stalons1;stalons2];
            indtri=[indtri1;indtri2+length(stalats1)];
%%%%            indtri=[indtri1;indtri2+ntri1];
        else
            stalats=stalats1; stalons=stalons1; indtri = indtri1;
        end
    end
    ntri1 = ntri1+ntri2;
else
    stalats=stalats1; stalons=stalons1; indtri = indtri1; ntri1 = ntri1;
end

if (ntri1==0)
    fprintf('[WARN] no triad detections for day %03d\n',jdmonth);
    detectv = [];
    return
end

detecttriad = detectv;
clear detectv
