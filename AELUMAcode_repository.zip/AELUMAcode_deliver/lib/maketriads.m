% AELUMA public bundle
%
% maketriads:
%       choose groups of triads based on Delauney triangulation
%
% input:
%	xx, yy - input vectors of station latitudes & longitudes 
%       icull - choose to cull triangles based on minimum & maximum angles, and rmax (in km)
%               0 = no, 1=YES
%       minang - throw out triangles with any interior angle < minang (dummy if icull=0)
%       maxang - throw out triangles with any interior angle > maxang (dummy if icull=0)
%	rmax - maximum range (km)
%	icase - 3 cases available
%		1 = input is in km
%       2 = input is in lat/lon, convert to flat based on centroid coordinates
%       3 = do stereographic projection (useful if network covers a very large area)
% output:
%	ntri - number of triangles
%	indtri - ntri x 3 matrix giving indices of stations for each triad
% History:
%       R.2016.336 2016-12-01 IRIC DMC: public release
%
function [ntri,indtri] = maketriads(xx,yy,icull,minang,maxang,rmax,icase);

xxsave = xx;yysave=yy;
if (icase==2)										% convert lat/long to yy/xx
	centlat = median(yy); centlon = median(xx);
    scale = cosd((yy+centlat)/2);
	yy = centlat + (yy-centlat)*111.11;
	xx = centlon + scale.*(xxsave-centlon)*111.11;
elseif (icase==3)
% do stereographic projection to get x,y location (could use arbtrary central points))
% from http://mathworld.wolfram.com/StereographicProjection.html
    centlat = 90; centlon = median(xx); Re = 6371;
    k = 2*Re./(1+sind(centlat)*sind(yy) + cosd(centlat)*cosd(yy).*cosd(xx-centlon));
    xx = k.*cosd(yy).*sind(xxsave-centlon);
    yy = k.*[cosd(centlat)*sind(yy) - sind(centlat)*cosd(yy).*cosd(xxsave-centlon)];
end

x=xx(:);y=yy(:);

% method of triangulation is the same for all cases
% for explanation of Delauney triangles, look at 
% http://www.mathworks.com/products/matlab/demos.html?file=/products/demos/shipping/matlab/demoDelaunayTri.html
dt = delaunayTriangulation(x,y);
%	ic=incenters(dt);
%	triplot(dt);
indtri = dt.ConnectivityList;
ntri=size(indtri,1);

% if triangles are culled, use flat Earth (cases 1 or 2)
if icull==1
	if icase==1 | icase==2							% if distances are on a flat Earth

% get rid of some of the triangles based on interior angles
		for jj=ntri:-1:1
			triyy=yy(indtri(jj,:));			% or trilats = dt.X(:,1); statlats = dt.X(:,2);
			trixx=xx(indtri(jj,:));
			rlen(1) = sqrt((triyy(1)-triyy(2))^2 + (trixx(1)-trixx(2))^2);
			rlen(2) = sqrt((triyy(1)-triyy(3))^2 + (trixx(1)-trixx(3))^2); 
            rlen(3) = sqrt((triyy(2)-triyy(3))^2 + (trixx(2)-trixx(3))^2);
            if (max(rlen)>rmax)
                indtri(jj,:) = [];
                continue
            end
% use formulae from wikipedia article on triangle (derives from law of sines)
			ang(1)=acos((rlen(2)^2+rlen(3)^2-rlen(1)^2)/(2*rlen(2)*rlen(3)));
			ang(2)=acos((rlen(1)^2+rlen(3)^2-rlen(2)^2)/(2*rlen(1)*rlen(3)));
			ang(3)=acos((rlen(1)^2+rlen(2)^2-rlen(3)^2)/(2*rlen(1)*rlen(2)));
			ang=ang*180/pi;
			rtrimean(jj) = mean(rlen);
% if an angle is too wide or narrow, get rid of triangle
			if min(ang)<minang | max(ang)>maxang
				indtri(jj,:) = [];
			end
		end

    elseif icase==3
% get rid of some of the triangles based on interior angles side distances
        for jj=ntri:-1:1
            trilats=yysave(indtri(jj,:));            % go back to input latitudes and longitudes
            trilons=xxsave(indtri(jj,:));
            londist = (trilons(1)-trilons(2))*cosd((trilats(1)+trilats(2))/2);
            rlen(1) = sqrt((trilats(1)-trilats(2))^2 + (londist*londist));
            londist = (trilons(2)-trilons(3))*cosd((trilats(2)+trilats(3))/2);
            rlen(2) = sqrt((trilats(2)-trilats(3))^2 + (londist*londist));
            londist = (trilons(3)-trilons(1))*cosd((trilats(3)+trilats(1))/2);
            rlen(3) = sqrt((trilats(3)-trilats(1))^2 + (londist*londist));
            rlen = rlen*111.11;
            if (max(rlen)>rmax)
                indtri(jj,:) = [];
                continue
            end
% use formulae from wikipedia article on triangle (derives from law of sines)
            ang(1)=acos((rlen(2)^2+rlen(3)^2-rlen(1)^2)/(2*rlen(2)*rlen(3)));
            ang(2)=acos((rlen(1)^2+rlen(3)^2-rlen(2)^2)/(2*rlen(1)*rlen(3)));
            ang(3)=acos((rlen(1)^2+rlen(2)^2-rlen(3)^2)/(2*rlen(1)*rlen(2)));
            ang=ang*180/pi;
% if an angle is too wide or narrow, get rid of triangle
            if min(ang)<minang | max(ang)>maxang
                indtri(jj,:) = [];
            end
        end

	else
		disp('wrong case')
		return
	end
end

ntri=size(indtri,1);
