% AELUMA public bundle
%
% jdate:
%       converts a calendar date array to julian date array
%
% History:
%       R.2016.336 2016-12-01 IRIC DMC: public release
%
function [jdate] = jdate(date)
[row,col] = size(date);
jdate = zeros(col,1);
c = 0;
for d=date
   c = c+1;
   dc = char(d);
   iy = str2num(dc(1:4));
   im = str2num(dc(6:7));
   imd = str2num(dc(9:11));
   jdate(c) = iy*1000 + fix(datenum(double(iy),double(im),double(imd)) - datenum(double(iy),1,1)) + 1;
end
