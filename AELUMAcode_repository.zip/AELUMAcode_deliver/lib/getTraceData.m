% AELUMA public bundle
%
% getTraceData:
%       a snippet MATLAB code to get station information using IRIS FDSN web service
% 
% History:
%       R.2018.085 2018-03-26 IRIS DMC: added matchtimeseries to URL to fetch  metadata that is likely to match available time series data
%       R.2018.067 2018-03-08 IRIS DMC: added a check for blank scale
%       R.2016.336 2016-12-01 IRIC DMC: public release
%

traceStart = strrep(dayStart,' ','T')
traceEnd   = strrep(dayEnd,' ','T')

fprintf ('[INFO] station availability quick check: %s to %s\n',traceStart,traceEnd);

%
% web services expects '--' for blank location code
%
requestLoc = checkLocCode(loc);

%
% station service parameters
%
url        = 'http://service.iris.edu/fdsnws/station/1/query';
sta        = '????';
level      = 'channel';
restricted = 'false'
comments   = 'true';
timeseries = 'true';
 
fullURL = sprintf('%s?net=%s&sta=%s&loc=%s&cha=%s&starttime=%s&endtime=%s&level=%s&format=text&includerestricted=%s&includecomments=%s&matchtimeseries=%s&nodata=404',url,net,sta,requestLoc,chan,traceStart,traceEnd,level,restricted,comments,timeseries);
fprintf('[INFO]:  checking availability via\n%s\n',fullURL);
[str,status] = urlread(fullURL);

lines = strsplit(str,'\n');
%str
if length(lines)>1
   fprintf('[INFO]: availability check returned %i records\n',length(lines)-1);
end

for rec = 2:length(lines)
   if length(lines{rec}) > 1
      %
      % support for blank location returned by the web services
      %
      thisLine       = strrep(lines{rec},'||','|  |');
      fields         = strsplit(thisLine,'|');
      fsamp(rec)     = str2num(fields{15});
      chaname(rec,:) = fields{4};
      wfname(rec,:)  = fields{2};
      thisDate       = strsplit(fields{16},'T');
      c              = strsplit(thisDate{1},'-');
      t              = strsplit(thisDate{2},':');
      jd             = jday(str2num(char(c(1,1))),str2num(char(c(1,2))),str2num(char(c(1,3))));
      startt(rec)    = epoch(str2num(char(c(1,1))),jd,str2num(char(t(1,1))),str2num(char(t(1,2))),str2num(char(t(1,3))));
      thisDate       = strsplit(fields{17},'T');
      c              = strsplit(thisDate{1},'-');
      try
         t              = strsplit(thisDate{2},':');
         jd             = jday(str2num(char(c(1,1))),str2num(char(c(1,2))),str2num(char(c(1,3))));
         endt(rec)      = epoch(str2num(char(c(1,1))),jd,str2num(char(t(1,1))),str2num(char(t(1,2))),str2num(char(t(1,3))));
      catch
         endt(rec)   = epoch(2029,01,0,0,0);        % date in future
      end
      try
         scl(rec) = str2num(fields{12});
      catch
         scl(rec) = 0;
      end
   end
end
