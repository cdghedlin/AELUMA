% ***********************************************************************************
% ***********************************************************************************
%
%		Read in data one day at a time - (but keep code to allow for multiple days)
%
% ***********************************************************************************
% ***********************************************************************************

% choose time window
clear savelons savelats datasave

maxgap = 2;

for julday=julday:julday
    fprintf('\n======== Day %d ========\n',julday);
    gapcounter=0;
    nodatacounter=0;
    
    jd1=julday; ihr1=0; imn1=00; isc1=0; 
    jd2=julday; ihr2=23; imn2=59; isc2=60;
    [mo1,day1] = jul2cal(iyr,jd1); 
    [mo2,day2] = jul2cal(iyr,jd2);
    t0=epoch(iyr,jd1,ihr1,imn1,isc1);
    tend=epoch(iyr,jd2,ihr2,imn2,isc2);
    [mo1,day1] = jul2cal(iyr,julday); 
    tjday=epoch(iyr,jd1,0,0,0);
    tcorr = tjday-t0;

% ***********************************************************************************
% ***********************************************************************************
%
%	sections 3  Read data. Run loop over each station
%
% ***********************************************************************************
% ***********************************************************************************

    fprintf('\n---> sections 3 - loop over each station\n\n');
    clear ind

    % only use stations that were turned on before this day and turned off after
    ind=find(staondateo-iyr*1000 < julday & staoffdateo-iyr*1000 > julday);
    clear nstat st stalats stalons staondate staoffdate
    nstat=length(ind); st=sto(ind); stalats=stalatso(ind);
    stalons=stalonso(ind); staondate=staondateo(ind); staoffdate=staoffdateo(ind);
    clear ind
    
    tic
    jstat = 0;
    fprintf('\n[INFO]T0:%0.8f Tend:%0.8f\n',t0,tend);
    for istat=1:nstat
        fprintf('\n..... Station %3i -  %s',istat,st(istat).StationCode);

        clear findwfentries ind amp
        findwfentries=ismember(cellstr(wfname),cellstr(st(istat).StationCode));
        ind=find(findwfentries == 1); clear findwfentries
 %       fsampsta = fsamp(ind);      % sample rate for this station
% this next line should never be necessary
        if (fsamp(ind) ~= st(istat).SampleRate) continue; end

        if length(ind)>1
% klugy fix, just choose the first one arbitrarily
            disp('  may be a problem with ind')
            ind = ind(1);
        end
        fsampsta = fsamp(ind);      % sample rate for this station

% check that at least one trace from this station spans part of the day
        ptsum=0;
        for i=1:length(ind)
          if endt(ind(i)) < t0 | startt(ind(i)) > tend
            ptsum=ptsum+0;
          else
            ptsum=ptsum+1;
          end 
        end
        if ptsum < 1
          nodatacounter=nodatacounter+1;
          fprintf('  [WARN] skipping %s record: no data', st(istat).StationCode); continue;
        end

        clear ptsum
        msflag=0;
        sta=char(cellstr(st(istat).StationCode));
        nsample=0;        

        % based on sample rate fsampsta
        marker=zeros(1,86400*fsampsta+1000);

        % make vector of time points (tfromdatabase)
        clear tfromdatabase afromdatabase
        for i=1:length(ind)
          clear amptmp
          tfirstpoint=t0;
          tlastpoint=tend;
          if tlastpoint-tfirstpoint > 1/fsamp(ind(i));            
              [fy, fd, fh, fm, fs] = ep2dat(tfirstpoint);
              [fmo,fdm] = jul2cal(fy,fd);
              [ey, ed, eh, em, es] = ep2dat(tlastpoint);
              [emo,edm] = jul2cal(ey,ed);
              traceStart = dayStart;
              traceEnd   = dayEnd;
%
% web services expects '--' for blank location code
%
              requestLoc = checkLocCode(loc);
              tr = irisFetch.Traces(net,st(istat).StationCode,requestLoc,chan,traceStart,traceEnd);
              if isempty(tr) continue; end; %exit read_data function when the data are not found
              amptmp = tr.data;
              senstmp = tr.sensitivity;

              if (max(abs(amptmp))==0)
                fprintf('  [WARN] skipping %s record: all zeroes', st(istat).StationCode); continue;
              end
              if (senstmp ~=0)
                amptmp = amptmp/senstmp;
              end

%  XXX klugy fix (problem found for BDF data , station N25K)
             if (length(amptmp) > length(marker))
                    disp('more data than expected, skipping trace')
                    continue
             end; % exit wrong sample rate

              if isempty(amptmp) continue; end;
              p1=round((tfirstpoint-t0)*fsamp(ind(i)))+1;
              p2=p1+length(amptmp)-1;              
              afromdatabase(p1:p2)=amptmp(1:length(amptmp));  
              tfromdatabase(p1:p2)=[t0+(p1-1)/fsamp(ind(i)):1/fsamp(ind(i)):t0+(p2-1)/fsamp(ind(i))];
              marker(p1:p2)=marker(p1:p2)+1;
              if(max(marker) > 1)
                fprintf('max marker');
                pause(10)
              end
         end  
       end 
       clear ind2
       ind2=find(marker ~= 0); 
       marker(ind2)=1;
       nsample=length(ind2); clear ind2
       nsampleexp=(tend-t0)*fsamp(ind(1))+1;
       srate = round(fsamp(ind(1)));
       delt = 1/srate;

       % fill in where there are gaps in data 
       alltime=t0+[0:nsampleexp-1]/srate;
       nmiss = nsampleexp-nsample;
       if nmiss > maxgap
            gapcounter=gapcounter+1;
            fprintf('   [WARN] %d pts missing, skipping record \n',nmiss); 
            continue; 
        end;

        if nmiss ~=0 % fill in gaps in data
% first collapse data from database into a continuous timeseries with all gaps documented in collapsed vector of time points
          clear indinterp
          indinterp=find(tfromdatabase ~= 0);
          tcollapsed=tfromdatabase(indinterp);
          acollapsed=afromdatabase(indinterp); 
          clear indinterp
          interpamp = interp1(tcollapsed,acollapsed,alltime,'linear','extrap'); 
          a=interpamp;t=alltime; nsample=length(a); a=a(:);             
          clear alltime tfromdatabase interpamp afromdatabase tcollapsed acollapsed
          if nmiss > maxgap/2
            st(istat).StationCode
	        fprintf('   [WARN]: filling in a gap of length %d \n',nmiss)
           end
        else
           a = afromdatabase;
           t = alltime; nsample = length(a); a = a(:);
           clear alltime tfromdatabase interpamp afromdatabase tcollapsed acollapsed
        end

        jstat = jstat + 1;

% save data to matrix
        ndec = fsampsta/fsfinal;
 
        if ndec > 1
% lowpass filter the data first
            [outdat]=mybandpassw(a,fsampsta,0,fnyq);
            if (mod(ndec,1)==0)
                datasave(:,jstat) = outdat(1:ndec:end); clear a outdat
            else    %  interpolate
                tq = t-t0;
                tinterp = 0:1/fsfinal:24*3600;
                dataint = interp1(tq,outdat,tinterp);       % interpolation
                datasave(:,jstat) = dataint;
            end
        else
            datasave(:,jstat) = a(1:end); clear a
        end

        savelats(jstat)=stalats(istat);
        savelons(jstat)=stalons(istat);
        fprintf('\n[INFO] time to read 1 station: %f\n', toc)
        fprintf ('\n')
    end	            % END LOOP OVER STATIONS for this day

    datasave = datasave';       %   (put this in the order (jstat,xlen)
    
    fprintf('\n[INFO] time to read in data at %d stations: %f\n',jstat, toc)
    nsave = jstat;
    if (nsave==0) return; end
%   tsave = t - t0;        % time wrt start of time window
    tsave = 0:1/fsfinal:24*3600;

% ***********************************************************************************
%  plot positions of stations that have been read in
% ***********************************************************************************
        
    if makeplots ~= 0
 	   fig_h = figure(5);hold on,
 	    plot(savelons,savelats,'ko','MarkerFaceColor','r') 
 %      legend('coast','all stations','not available','array stations','Location','SouthWest')
	   hold on,   
       set (fig_h,'Position',[1 150 screenWidth screenHeight],'Color',[1 1 1]);
    end

end

clear amptmp t marker
return
