% AELUMA public bundle
% flagStragglers: at each iteration,
%      flag detections that have fewer than mincluster neighbours
%       within the maximum allowable time for the array configuration
% XX: ? change to a stricter criterion to require a tighter cluster ?
%
% input:
%	trilat,trilon : locations of remaining detections
%	ttsig : associated arrival times
%	iii - indices of detections under consideration
%   mincluster - minimum cluster size
%   celermin - minimum celerity (km/s)
%   narray : the array number associated with each detection
%
% output: 
%	iloner : detections flagged as isolated
%
function [iloner] = flagStragglers(trilat,trilon,ttsig,iii,mincluster,celermin,narray);

% NOTES: I could require one member of a cluster to have an amplitude cutoff
% (ie higher than ampcut, could also do this in group_Detections code)

% *************************************************************************
%  flag groups of detections that are too small to be part of an event
%       with mincluster detections
%for each triad
%		find detections that are relatively spatially/temporally isolated
% *************************************************************************

% get ordered, unique locations of triads  (from narray)
ntri = max(narray);
utrilat = zeros(ntri,1)+mean(trilat) + 180;
utrilon = zeros(ntri,1)+mean(trilon) - 90;

for jj=1:ntri
    ind = find(narray==jj);
    if isempty(ind) continue; end
    utrilat(jj) = trilat(ind(1));
    utrilon(jj) = trilon(ind(1));
end

slats = utrilat; slons = utrilon;
sigtimes = ttsig(iii); striad = narray(iii);

flag2 = ones(size(sigtimes));      % flag for groups < mincluster
ndet = length(sigtimes);

for jf = 1:ndet
    if (flag2(jf)==0) continue; end
% for each detection, find distance to other detections
    latdist=(slats(striad(jf))-slats)*111.11;
    londist=(slons(striad(jf))-slons)*cosd(slats(striad(jf)))*111.11;
    rdist = sqrt(latdist.*latdist+londist.*londist);        % km
% find tmax = max allowable time
%    tmax = max(rdist)/celermin;
% find arrival time differences
    timediff = abs(sigtimes(jf)-sigtimes);

%  require tightish cluster (nearest triads must have mincluster detections)
    rsort = sort(unique(rdist)); imax = min(5*mincluster,length(rsort));
    tmax = rsort(imax)/celermin;
    ind = find(timediff(:)<tmax);
 
% now expand out the ranges to cull by celerity - SKIP (too slow)
%     rangex = rdist(striad);
%  avoid divide by zero error
%     celertest = max(0.01,rangex)./max(0.00001,timediff);       %  all triads
%     ind = find(celertest(:) >celermin & timediff(:) <tmax);

% are there mincluster unique triads in group?
    if (length(ind)>=mincluster)
        dum = sort(striad(ind));
        narrdet = length(find(diff(dum)>0))+2;      % must include 'self' in cluster
        if narrdet>= mincluster       % enough detections at unique triads?
%            flag2(ind) = 0;           % these points belong to a large enough group
            flag2(jf) = 0;           % this point belongs to a large enough group
        end
    end
end                 % end outer loop over triads (for jf = 1:ndet)

ind = find(flag2==1);                   % subset of iii that are isolated
iloner = iii(ind);                     %  eliminate these before next round
