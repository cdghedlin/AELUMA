% NOTES XX: the arrayTaup.m method is slow because ALL station pairs are considered
%  it would be worth trying to use subsets of the station pairs. Note that the time
%  increases approx as N*n, where N is the number of stations in the array
%  the XR matrix set up here (actually in Amat) would reflect which method chosen
%   1) all station pairs (as is currently done)
%   2) could only use stations pairs within radius maxr  *************
% (maxr is the distance from (approx) the array center to the most distant station)
%
% arrayConfiguration:
%       get location matrix for a given array
%
% input:
%       jarr - array number of interest
%       iii: indices of stations that belong to the array of interest
%       marr : number of stations in the given array
%       savelats,savelons : station locations within the array
% output:
%       XR : position matrix
%       Amat - relative positions between all pairs
%       staPairs - info on all pairs
%
function [XR,Amat,staPairs] = arrayConfiguration(jarr,iii,marr,savelats,savelons);

Mperdegree = 111110;                            % metres per degree of latitude
                                       
msta = marr(jarr);
arrlats=savelats(iii);
arrlons=savelons(iii);
clon(jarr)=mean(arrlons);       % array center
clat(jarr)=mean(arrlats);
% get xloc and yloc for each station within the array wrt clon,clat
% does not take elevation differences into account
lonscale = cosd(clat(jarr));
xloc = (arrlons - clon(jarr))*Mperdegree*lonscale;
yloc = (arrlats - clat(jarr))*Mperdegree;
% positions
XR(:,1) = xloc(:);
XR(:,2) = yloc(:);

% construct Amat - relative position matrix and
% staPairs - info on pairs
nrow = sum(1:msta-1);
Amat = zeros(nrow,2);
staPairs = zeros(nrow,3);       % stations pairs & interstation distances
icount = 0;
for ksta = 1: msta-1
    for kk = ksta+1:msta
        icount = icount + 1;
        Amat(icount,1) = xloc(kk)-xloc(ksta);
        Amat(icount,2) = yloc(kk)-yloc(ksta);
        staPairs(icount,1) = ksta;
        staPairs(icount,2) = kk;
        staPairs(icount,3) = sqrt(Amat(icount,1)*Amat(icount,1) + Amat(icount,2)*Amat(icount,2));
    end
end
