% to find row and column values in a matrix
%
%   input
%       A: 2D matrix
%       value; the value to find in that matrix
%       operation: (1 = value), (2 > value) (3 >= value) (4 < value) (5 <= value)
%   output
%       row,column        - vector of all [row,column] indices where that value is found
%
%   usage:  [row,column] = matrixFind(A,value,N);
%           eg.  to find A == value;   [row,column] = matrixFind(A,value,1);
%           eg.  to find A > value;    [row,column] = matrixFind(A,value,2);
%           eg.  to find A >= value;   [row,column] = matrixFind(A,value,3);
%           eg.  to find A < value;    [row,column] = matrixFind(A,value,4);
%           eg.  to find A <= value;   [row,column] = matrixFind(A,value,5);

function [row,column] = matrixFind(A,value,operation);

[nrow,ncol] = size(A);

if (operation == 1)
    ind = find(A == value);
elseif (operation == 2)
    ind = find(A > value);
elseif (operation == 3)
    ind = find(A >= value);
elseif (operation == 4)
    ind = find(A < value);
elseif (operation == 5)
    ind = find(A <= value);
else
    disp('bad operation in matrixFind')
    ind = [];
    fprintf('Press any key to continue');
    w = waitforbuttonpress;
    fprintf('\n');
    close all;
end

row = mod(ind,nrow);
column = 1 + ceil((ind-row)/nrow);

ii = find(row==0);
if isempty(ii) return; end

row(ii) = nrow;
column(ii) = ind(ii)/nrow;
return
