% clumpiness 		define clumpiness for the event
%
%	[ermin,eazpie] = clumpiness(stalats,stalons,srclat,srclon,iplot);
%
%	input:
%       stalats,stalons - source positions (latitude and longitude vectors)
%       srclat,srclon - source position
%	output:
%%%%%%%       edense - a measure of clumpiness for the event
%       ermin - minimum source-station distance
%       eazpie - angle subtended by all detecting stations

function [ermin,eazpie] = clumpiness(stalats,stalons,srclat,srclon,iplot);

Nsta = length(stalats);

SPHEROID = referenceEllipsoid('wgs84', 'km');

% define clumpiness as the mean distance from each station
% to the source divided by the square root of the number of stations
% (square root because AREA increases with size of group)

[staclump, az] = distance(srclat,srclon,stalats,stalons,SPHEROID);
% edense = mean(staclump)/sqrt(Nsta);
ermin = min(staclump);      % how far source is from nearest station

% now get angle from source to receiver subtended by all stations
meanlat = mean(stalats); meanlon = mean(stalons);
[rrmn, azmn] = distance(srclat,srclon,meanlat,meanlon,SPHEROID);
[newaz] = Csetminmax(az,azmn-180,azmn+180);
eazpie = max(newaz)-min(newaz);

if iplot == 1
    load coast
    minlat = min([srclat min(stalats)]);
    maxlat = max([srclat max(stalats)]);
    minlon = min([srclon min(stalons)]);
    maxlon = max([srclon max(stalons)]);

    figure(8),clf,plot(stalons,stalats,'ko')
    hold on,plot(srclon,srclat,'rp','LineWidth',2)
    plot(long,lat,'b')
    ylim([minlat maxlat]),xlim([minlon maxlon])
    hold on,plot(meanlon,meanlat,'rs','LineWidth',2)
    disp('in clumpiness')
    keyboard
end


return
