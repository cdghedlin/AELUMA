% AELUMA public bundle
%
% mybandpassw:
%       do bandpass filtering with filtfilt (4 poles), but don't decimate the data
%       apply a tukeywindow prior to filtering
%
% input:
%	sin - input signals
%	fs - sampling rate
%	flo fhi -  low and high pass frequencies
% output: 
%	outdat - output time series 
%              
% History:
%       R.2016.336 2016-12-01 IRIC DMC: public release
%
function [outdat]=mybandpassw(sin,fs,flo,fhi);
%
nyq = fs/2;xlen=length(sin);
twin = tukeywin(xlen,0);
% lowpass filter
[B,A] = butter(4,fhi/nyq);
lpsig1 = filtfilt(B,A,sin(:).*twin(:));

% hipass if flo > 0 (new sampling rate)
if flo > 0
   [B,A] = butter(4,flo/nyq,'high');
   outdat = filtfilt(B,A,lpsig1);
else
   outdat=lpsig1;
end
