% Nxcorr:
%       do multi-channel correlation for an arbitrary number of stations
%
% input:
%       dseg - N data segments (size nt X N)
%       fs - sample rate
%       nrow - number of x-corrs to do
% output:
%       tau - vector of time delays for each pair
%       xmag - vector of cross-correlations for each pair
%
function [tau,xmag]=Nxcorr(dseg,fs,maxlag,nrow);

nsta=size(dseg,2);
nt=size(dseg,1);
% tdel = zeros(nsta);                % delay times between each pair
xmag = zeros(nrow,1);                % minimum cross-correlation
tau = zeros(nrow,1);

icount = 0;
for jj = 1:nsta-1
    for kk = jj+1:nsta
        icount = icount + 1;
        c=xcorr(dseg(:,jj),dseg(:,kk),maxlag,'coeff');
        [cmax,iic] = max(c);
        xmag(icount) = cmax;
        tau(icount) = (iic-maxlag-1)/fs;
    end
end

% note that the time delay tau is not the time delay
% from site j to site k but instead is the negative of that
%  if tau is negative it means that the signal arrives
% first at site j by -tau seconds
