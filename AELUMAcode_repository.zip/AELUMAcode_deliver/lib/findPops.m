% to find separate populations within a group of numbers in 1D
% currently only allows for two populations
%
%   input
%       x: vector of values to examine
%   output
%       iMain - larger of iS, or iP (or all, if populations are not separate)
%       iS - index values for population with lower values
%       iP - index values for slower population
%
%   usage:  [iMain,iS,iP]=findPops(x);

function [iMain,iS,iP]=findPops(x);

%  figure(5),clf,hh = histogram(x,25);
%  [hcounts,hedges]=histcounts(x,21);

% find largest grouping of celerities
meanx = mean(x); xstd = std(x);
% decide on starting point
iS = find(x<=meanx); meanS=mean(x(iS));
iP = find(x>meanx); meanP=mean(x(iP));

xdist = zeros(2,length(x));
%     (this is roughly equivalent to k-means testing - do at most 3 iterations   )
for jj = 1:3
    meanSold = meanS; meanPold = meanP;
    xdist(1,:)=abs(x-meanS); xdist(2,:) = abs(x-meanP);
    [dum,idx] = min(xdist);
    iS = find(idx==1); meanS=mean(x(iS));
    iP = find(idx==2); meanP=mean(x(iP));
%    [meanS meanP length(iS) length(iP)]
    if ((meanS==meanSold) & (meanP==meanPold)) break; end
end

stdS=std(x(iS)); lis = length(iS);
stdP=std(x(iP)); lip = length(iP);
%  check whether there are truly 2 populations (2 methods)
% populations are separated or one population comprises 80% of total
iftwo = ( (meanS+stdS)<meanP | meanS < (meanP-stdP) |lis <= 0.25*lip |lis >= 4*lip);

if iftwo
    if lis > lip
        iMain = iS;
    else
        iMain = iP;
    end
else
    iMain = [1:length(x)];
end

