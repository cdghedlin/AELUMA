% group_detections:
%       groups detections into clusters, each corresponding to a unique source
%       returns and approximate source location and time
%
%       Detections with arrival time and azimuth info are used to find an approx source location
%   first,  seach over a spatial grid to find a most likely source location
%           find # of detections that give an adequate fit to the azimuth data
%	        at least NN arrays must have a reasonable fit to azimuths and travel time
%           have to add an amount given by the maximum angle between
%           the gridpoints (depends on distance between gridpoints and on
%           the reciprocal of the distance to the grid)
%   next,  do a 3D grid search over this narrower spacial grid and the entire time range
%           the gridpoint with the most associated detections with the correct travel
%           times that fit, as well as azimuths that fit, are returned in iboth
%           these points are removed from further consideration
%	
% input:
%	arrlat,arrlon : vectors of array latitudes & longitudes (median)
%	azmth,ttsig : azimuths and arrival times to source at each array
%	testlat,testlon : vectors defining search grid
%   narray : the array number associated with each detection
%	Afit - minimum target azimuth misfit		(add +dazmth/kmdist)
%	mincluster - minimum cluster size
%	iii - indices of detections under consideration
%   distgrid, azgrid - matrix of distances&azimuths from array center to gridpoints
%	celermin, celermax - minimum and maxium celerity (km/s)
%	tinc - sample t0 every tinc seconds
%   kmcutoff - maximum distance of nearest detection (for each gridpoint)
%   onoffgrid - states whether the gridpoint needs to be considered on this interations
% output:
%	fitboth : # arrays/triads with adequate azimuth & travel time at each gridpoint
%   midlat, midlon - center of grid to explore in grid_Search
%   errlat,errlon - error in latitude & longitude
%   besttime - inital best time fit
%	iboth - indices for points that fit both azimuth and time
%   onoffgrid - states whether the gridpoint needs to be considered or not if future interations
%   bestlat, bestlon - initial best location
%

function [fitboth,midlat,midlon,errlat,errlon,besttime,iboth,onoffgrid,bestlat,bestlon] = group_detections(arrlat,arrlon,azmth,ttsig,testlat,testlon,narray,Afit,mincluster,iii,distgrid,azgrid,celermin,celermax,tinc,kmcutoff,onoffgrid)

% problems still exist if the signals are too close together, in this case
% a single station may see signals from both events & they are lumped together

SPHEROID = referenceEllipsoid('wgs84', 'km');
nlon=length(testlon); nlat=length(testlat);
% fithboth saves the number of detections that fit both azimuth and celerity at each gridpoint
fitboth = zeros(nlon,nlat);
fitTime = zeros(nlon,nlat);         % saves the optimal time window at each gridpoint
spafit = zeros(nlon,nlat);         %  # detections with azimuths that fit each gridpoint (spatial grid)
gridsize = nlon*nlat;

maxdist = max(distgrid(:));
tfirst = max(0,ttsig(iii(1)) - maxdist/celermin);   % first sample point
tlast = min(24*3600,ttsig(iii(end)));               % sample origin points from tfirst to last detection point
twindo = [0:tinc:tlast]; ntwin = length(twindo);
dlat = abs(testlat(2)-testlat(1));
dlon = abs(testlon(2)-testlon(1));

% subset of detections under consideration
niii = length(iii);
slats=arrlat(iii); slons=arrlon(iii);
sazmth = azmth(iii); sigtimes = ttsig(iii);
distgrid=distgrid(:,iii); azgrid = azgrid(:,iii);
sarray = narray(iii);

% deal with half-angle from one gridpoint to the next
% divide dazmth by kmdist (distance from array to gridpoint)
% dazmth = s/r*180/pi      (converts to degrees)
dazmth = 111.11*dlat*180/pi/2;
fbest = mincluster;         % do time sweeps if fbest>= mincluster criterion holds

% FIRST only look at the spatial fit to azimuths
icount = 0;
for ilat = 1:nlat
	for ilon = 1:nlon
        icount = icount+1;
        if (onoffgrid(ilon,ilat) == 0) continue; end;
        kmdist = distgrid(icount,:)';
        az = azgrid(icount,:)';
		misfit = abs(Csetminmax(sazmth-az,-180,180));		% azimuth misfit
        jj = find(misfit<= (Afit+dazmth./kmdist));
% # detections with azimuths with acceptable fit (not necessarily unique arrays)
        njj = length(jj);	        %
        if (njj < mincluster) onoffgrid(ilon,ilat) = 0; continue; end               % too few detections
        if (min(kmdist(jj)) > kmcutoff(icount))
            onoffgrid(ilon,ilat) = 0;
            continue;
        end
% # of detections at unique triads or arrays
        dum = sort(sarray(jj));
        narrdet = length(find(diff(dum)>0))+1;      % # unique detections
%        spafit(ilon,ilat) = narrdet + njj/niii;       %  augment based on # detections
        spafit(ilon,ilat) = narrdet + 0.9999-mean(misfit(jj)./(Afit+dazmth./kmdist(jj)));    % augment for best azimuth misfit
        if (narrdet < mincluster)    % if < mincluster detections fit the azimuths, skip for future iterations
            onoffgrid(ilon,ilat) = 0;
            continue;
        end
    end
end

% XXX NOTE: the loop above would identify swarms, consider treating
% swarm detections a bit differently in refined source routine

% find narrower spatial region
[maxdet,rowmax,columnmax] = maxMatrix(spafit,1);
% optimal location
optlat = testlat(columnmax); optlon = testlon(rowmax);   % [optlat optlon]

% make sure that I am using at least best 5% of the grid area
sortfit = sort(spafit(:));
fitcut = min([sortfit(end-floor(0.05*gridsize)) 0.85*maxdet]);
fitcut = max(fitcut,1);                 % backstop for mincluster =2
[row,column] = matrixFind(spafit,fitcut,3);

minlati = min(column); maxlati = max(column);
minloni = min(row); maxloni = max(row);
dogrid = zeros(nlon,nlat);;
dogrid((column-1)*nlon + row) = 1;
                      
% -------------------------------------------------------------------------
% XXXX   I could narrow the time window here, but skipping it for now
                      
% -------------------------------------------------------------------------
% do the search over this narrower region
for ilat = minlati:maxlati
    for ilon = minloni:maxloni
        if (~dogrid(ilon,ilat)) continue; end;
        icount2 = (ilat-1)*nlon + ilon;
        kmdist = distgrid(icount2,:)';
        az = azgrid(icount2,:)';
        misfit = abs(Csetminmax(sazmth-az,-180,180));        % azimuth misfit
        jj = find(misfit<= (Afit+dazmth./kmdist));
% XXXXX   put next 2 lines in a function - equivalent to length(unique(sarray(jj)));
        dum = sort(sarray(jj));
        narrdet = length(find(diff(dum)>0))+1;
        if (narrdet < mincluster)    % if < mincluster arrays fit the azimuths, skip future iterations
            onoffgrid(ilon,ilat) = 0;
            continue;
        end
%
% the lines above count the total number of arrays with azimuths that fit
% which might encompass several sources.
% only work through the time sweep if we might find the largest cluster.
        if (narrdet < fbest) continue; end

% for each potential origin time (defined in twindo),
% compute expected travel time for this gridpoint & count number within expected range
        kmA = kmdist(jj); ttA = sigtimes(jj); sarrayA = sarray(jj);
        misfitA = misfit(jj);
        tmin = -tinc + kmA/celermax;
        tmax = tinc + kmA/celermin;

        ntime=zeros(ntwin,1); narrayfit=zeros(ntwin,1);
        azmis = ones(ntwin,1);
        for kk = 1:ntwin
            t1 = twindo(kk);
            iclx = find((ttA-t1)>=tmin & (ttA-t1)<=tmax);   % subset with correct celerity
% count number of acceptable travel times,
            ntime(kk) = length(iclx);
% if 1) there are enough detections within the time range and
%  2) the distance to the nearest detection is within the cutoff for this gridpoint
% THEN count number of arrays with acceptable travel times
            if ( (ntime(kk) > mincluster) & (min(kmA(iclx)) < kmcutoff(icount)))
%%%%%                narrayfit(kk) = length(unique(sarrayA(iclx)));
% this is a faster way to get unique arrays/triads
                dum = sort(sarrayA(iclx));
                narrayfit(kk) = length(find(diff(dum)>0))+1;
%                azmis(kk) = mean(misfitA(iclx)./(Afit+dazmth./kmA(iclx)));        % azimuth misfit
            end
        end

% measure of fitness governed by number of detecting arrays and
        fitmeas = narrayfit + ntime/(1+niii);     %  augment based on # detections
%        fitmeas = narrayfit + 0.9999-azmis;  % favor best azimuths

        [maxfit,iwindo] = max(fitmeas);
        if (maxfit < mincluster)
            onoffgrid(ilon,ilat) = 0;
            continue;
        end

% there may be several values with equal maxfit in a row; get the one in the middle
        iwindo1 = iwindo;
        while (  (iwindo<=ntwin-1) && (fitmeas(iwindo+1) == fitmeas(iwindo))   )
            iwindo = iwindo + 1;
        end
        iwindo = floor(  (iwindo1+iwindo)/2);       % must be integer

% re-find the cluster corresponding to the time window chosen above
        misfit2 = abs(Csetminmax(sazmth(jj)-az(jj),-180,180));
        jboth = find((ttA-twindo(iwindo))>=tmin & (ttA-twindo(iwindo))<=tmax & misfit2 <=(Afit+dazmth./kmA));
        arrayclust = sarrayA(jboth);
        narrayclust = length(find(diff(sort(arrayclust))>0))+1;
 %       if (floor(maxfit) ~= narrayclust)
 %           disp('ERROR IN group_Detections') (not an error if ntime(iwindo) == niii)
 %           [ilat ilon maxfit length(jboth)]
 %           keyboard
 %       end

%   the function to be optimized consists of 2 parts;
%   1) number of array with detections: this is the most important
%   2) the average azimuth misfit of detections
%
        fitboth(ilon,ilat) =  maxfit;
        fitTime(ilon,ilat) =  iwindo;
        fbest = max(fbest,floor(maxfit));

	end                 % end loop over longitude
end                     % end loop over latitude

% finish up ---------------------------------------------------------------------

[maxvalue,jlon,jlat] = maxMatrix(fitboth,1);
ibest = (jlat-1)*nlon+jlon;

if (maxvalue==0)
    iboth=[];
    bestlat=0; bestlon=0; besttime=-1;
    errlat = 0; errlon = 0; midlat=0;midlon=0;
    return;
else
    bestlat = testlat(jlat); bestlon = testlon(jlon);
    iwindobest = fitTime(jlon,jlat);
end

% re-find the detections for the best point
% distance and azimuth from best point to all arrays
kmdist = distgrid(ibest,:); az = azgrid(ibest,:);
az=az(:); kmdist = kmdist(:);
tmin = -tinc + kmdist/celermax;
tmax = tinc + kmdist/celermin;
                                                												   
% for each cluster, both times & azimuths must agree reasonably well with the
% source location. Use this cluster & remove them in the main program
misfit2 = abs(Csetminmax(sazmth-az,-180,180));
besttime = twindo(iwindobest);
jboth = find((sigtimes-besttime)>=tmin & (sigtimes-besttime)<=tmax & misfit2<= (Afit+dazmth./kmdist));
iboth = iii(jboth); njjj = length(iboth);
arrayclust = sarray(jboth);
narrayclust = length(unique(arrayclust));

% get estimate of the location error, population of acceptable points
% has nearly same fitness level and also about close to the same time
% ie close to within 10 time points
% dsort=sort(fitboth(:),'descend'); minfit = min(0.95*maxvalue,dsort(50));
% population of acceptable points
ind = find(fitboth >= 0.95*maxvalue & abs(fitTime-iwindobest) < 10);
ilats = ceil(ind/nlon);
ilons = ind - (ilats-1)*nlon;

% errors in latitude and longitude are = half(range of values) + grid discretization
errlat = (max(testlat(ilats)) - min(testlat(ilats)))/2 + dlat;
%  care of wraparound at =/- 180 degrees
[wraplons] = Csetminmax(testlon(ilons),bestlon+180,bestlon+540);
errlon = (max(wraplons) - min(wraplons))/2 + dlon;
errlat = max(errlat,4*dlat);            % minimum value
errlon = max(errlon,4*dlon);
% errors in latitude and longitude are too high if there are 2 populations

% choose midpoint of area defined by errlat,errlon to start gridsearch (~= the 'best point')
midlat = (max(testlat(ilats))+ min(testlat(ilats)))/2;
midlon = (max(wraplons-360)+ min(wraplons-360))/2;
												
% print out result and return
fprintf('cluster size %d at %5.2f N, %6.2f W \n',njjj,bestlat,bestlon)
fprintf('%d unique arrays;  source time %d \n',narrayclust,twindo(iwindobest))

% do a least squares fit for the best location
%  equation is tan(azmth) = (xp-xs)*scale/(yp-ys)
% (xp,yp,tan(azmth),scale all known  (xp - longiture; yp - latitude)
% alter to xp-(tan(azmth)/scale)*yp = xs - ys (tan(sazmth)/scale)
   
%scale = (cosd(slats(jboth)) + cosd(bestlat))/2;
%tanaz = tand(sazmth(jboth)); tanaz = max(-57,tanaz); tanaz = min(tanaz,57);
%detlats = slats(jboth); detlons = slons(jboth);
%ylin = detlons(:) - (tanaz(:)./scale(:)).*detlats(:);
%xlin = -1*(tanaz(:)./scale(:));
%   brob = robustfit(xlin,ylin)
%[bls,bint] = regress(ylin,[ones(size(xlin)) xlin]);   % gives an estimate of errors
% bls should be close to bestlat, bestlon
   
% errors in latitude and longitude (in degrees) are = half(range of values) + grid discretization
%errlat = diff(bint(2,:))/2 + dlat;
%  care of wraparound at =/- 180 degrees
%[wraplons] = Csetminmax(bint(1,:),bestlon+180,bestlon+540);
%errlon = diff(wraplons)/2  + dlon;
% NOTE: errors in latitude and longitude are too high if there are 2 populations
%  midpoint of area defined by errlat,errlon to start gridsearch (not necessarily the 'best point')
%midlat = mean(bint(2,:));
%midlon = mean(wraplons-360);
   
return

% comment out the return to debug (or make plots) -------------------------------------------------

% plot of spatial fit function
color=jet(300);color(1,:) = 0.99*[1 1 1];
load coast

figure(33),clf                      % plot of spatial fit
latlim = [floor(min(testlat)) ceil(max(testlat))];
lonlim = [floor(min(testlon)) ceil(max(testlon))];
h=axesm('mapprojection','mollweid','maplonlimit',...
        lonlim,'maplatlimit',latlim,'frame','on','meridianlabel','on',...
        'parallellabel','on','mlabellocation',30,'plabellocation',10);
surfm(testlat,testlon,spafit'),colormap(jet),colorbar('vert')
hold on,plotm(optlat,optlon,'wo')
plotm(lat,long,'color',0.05*[1 1 1]);
ht = title('Initial spatial misfit','FontName','Comic');
ht.Position(2) = ht.Position(2) + 0.15;
axis off
% print('Triads_Stafit','-djpeg')
      
% ................................................................................
% plot of fitness function

figure(11),clf
h=axesm('mapprojection','mollweid','maplonlimit',...
    lonlim,'maplatlimit',latlim,'frame','on','meridianlabel','on',...
    'parallellabel','on','mlabellocation',30,'plabellocation',10);
surfm(testlat,testlon,fitboth'), colorbar('vert'),colormap(color)
% hold on,hb=plotm(bestlat,bestlon,'o','color',0.95*[1 1 1],'LineWidth',1);
hold on,plotm(bestlat,bestlon,'ko','MarkerFaceColor','w');
plotm(lat,long,'Color',0.05*[1 1 1],'LineWidth',1);
%  plotm(slats(jboth),slons(jboth),'k.')
axis off
ht = title('Fitness function','FontName','Comic');
ht.Position(2) = ht.Position(2) + 0.15;
% print('Triads_Fitness','-djpeg')
                                                  
% ................................................................................
  
% travel time & celerity plots
      
figure(21),clf,
subplot(3,1,1),plot(kmdist,sigtimes/3600,'ko')
hold on,plot(kmdist,(besttime+tmin)/3600,'r'),plot(kmdist,(besttime+tmax)/3600,'r')
plot(kmdist(jboth),sigtimes(jboth)/3600,'go'),grid
ylim([floor(besttime/3600)-0.1 max(besttime+tmax)/3600]), % xlim([0 max(kmdist(iboth))*1.1])
ylabel('T (hrs)')
celer = kmdist(jboth)./(sigtimes(jboth)-besttime);
subplot(3,1,2),plot(kmdist(jboth),celer,'ko'),grid
xlabel('R (km)'),ylabel('celerity (km/s)')
subplot(3,1,3),hist(celer),grid
 
tstart = floor(besttime/3600);
tend = ceil((besttime+max(tmax))/3600);
figure(2),clf,axes('position',[0.2 0.2 0.6 0.5])
plot(kmdist,sigtimes/3600,'ko','MarkerSize',4)
hold on,plot(0,twindo/3600,'r.'),grid
xlabel('R (km)','FontName','Comic')
ylabel('Time of day (hr)','FontName','Comic')
axis([0 max(kmdist(:)) tstart tend])
% print('Triads_TimeVsRa','-djpeg')
      
jaz = find(misfit2<= (Afit+dazmth./kmdist));
hold on,plot(kmdist(jaz),sigtimes(jaz)/3600,'go','MarkerSize',4)
% print('Triads_TimeVsRb','-djpeg')
      
hold on,plot(kmdist,(besttime+tmin)/3600,'r'),plot(kmdist,(besttime+tmax)/3600,'r')
hold on,plot(kmdist(jboth),sigtimes(jboth)/3600,'ro','MarkerSize',4)
axis([0 max(kmdist(:)) tstart tend])
% print('Triads_TimeVsRc','-djpeg')
      
% ................................................................................
      
% plot all detections within a given time range
      
latlim2=[min(floor(arrlat))-1 max(ceil(arrlat))+3];
lonlim2=[min(floor(arrlon))-4 max(ceil(arrlon))+2];
indt = find(sigtimes>= tstart*3600 & sigtimes<=tend*3600);     % all detections in time range
srcaz = Csetminmax(sazmth(indt)+180,0,360);
px = 0.5*cos(srcaz*pi/180);
py = 0.5*sin(srcaz*pi/180);
x = slats(indt); y = slons(indt);
x=x(:);y=y(:);

figure(7),clf,
h=axesm('mapprojection','mollweid','maplonlimit',...
    lonlim2,'maplatlimit',latlim2,'frame','on','meridianlabel','on',...
    'parallellabel','on','mlabellocation',10,'plabellocation',5);
hold on, colormap(flipud(jet))
plotm(lat,long,'color',0.05*[1 1 1],'LineWidth',1);
h=quiverm(x,y,px,py,'k',1);
scatterm(x,y,10,sigtimes(indt)/3600,'filled')
axis off
ht = title('Detections in time range','FontName','Comic');
ht.Position(2) = ht.Position(2) + 0.01;
cbar = colorbar('Position',[0.84 0.3 0.03 0.5])
ylabel(cbar,'Time of day (hr)','FontSize',8,'FontName','Comic')
% print('Triads_DetectionHrs','-djpeg')

%................................................................................
% plot all detections corresponding to a given event - (arrow plot)

srcaz = Csetminmax(sazmth(jboth)+180,0,360);
px = 0.5*cos(srcaz*pi/180);
py = 0.5*sin(srcaz*pi/180);
x = slats(jboth); y = slons(jboth);
x=x(:);y=y(:);
latlim2 = [floor(min(bestlat,min(x(:))-4)) ceil(max(bestlat,max(x(:))+8))];
lonlim2 = [floor(min(bestlon,min(y(:))-8)) ceil(max(bestlon,max(y(:))+8))];

figure(27),clf,
h=axesm('mapprojection','mollweid','maplonlimit',...
   lonlim2,'maplatlimit',latlim2,'frame','on','meridianlabel','on',...
   'parallellabel','on','mlabellocation',10,'plabellocation',5);
hold on, colormap(flipud(jet))
plotm(lat,long,'color',0.05*[1 1 1],'LineWidth',1);
h=quiverm(x,y,px,py,'k',1);
      
scatterm(x,y,20,(sigtimes(jboth)-besttime)/60,'filled')
hold on,plotm(bestlat,bestlon,'kp','MarkerSize',12,'MarkerFaceColor','r')
axis off
ht = title('Detections for a single event','FontName','Comic');
ht.Position(2) = ht.Position(2) + 0.01;
cbar = colorbar('Position',[0.86 0.3 0.03 0.5])
ylabel(cbar,'Time after Event (min)','FontSize',8,'FontName','Comic')
% print('Triads_Detection1E','-djpeg')

fprintf('best initial spatial location %5.2f N, %6.2f W \n',optlat,optlon)
fprintf('best coarse location %5.2f N, %6.2f W \n',bestlat,bestlon)
 
figure(8),clf,plot(sigtimes/3600,sazmth,'ko')
hold on,plot(sigtimes(jboth)/3600,sazmth(jboth),'ro')
                      
fprintf('\n\n end of group_Detections \n')
keyboard
