%  AELUMA public bundle
%
% clusterLookm2:
%       make a map of a cluster of points
%
%	clusterLook2(ptlat,ptlon,ttsig,azmth,indices,srclat,srclon)
%	
%	input:
%		ptlat ptlon : vectors of point latitudes & longitudes 
%		ttsig : arrival times 
%		azmth : azimuth 
%		indices : subset of points to plot
%		srclat,srclon : put a star on this point (skip if outside limits)

	function clusterLook2(ptlat,ptlon,ttsig,azmth,indices,srclat,srclon)

scale = 0.7;

len = length(indices);
mint = min(ttsig(indices)); maxt = max(ttsig(indices));
range=maxt-mint;
color = jet; ncol = max(size(color));
latlim=[floor(min(ptlat(indices)))-1 ceil(max(ptlat(indices)))+1]; 
lonlim=[floor(min(ptlon(indices)))-1 ceil(max(ptlon(indices)))+1];

h=axesm('mapprojection','mollweid','maplonlimit',lonlim,...
        'maplatlimit',latlim,'frame','on','meridianlabel','on',...
        'parallellabel','on','mlabellocation',4,'plabellocation',2);
load coast
plotm(lat,long,'color',0.05*[1 1 1]); hold on;
states = shaperead('usastatehi', 'UseGeoCoords', true);
geoshow(states,'FaceColor',0.99*[1 1 1],'EdgeColor',0.6*[1 1 1]);
plotm(ptlat,ptlon,'.','Color',0.6*[1 1 1]),hold on
%

orient = Csetminmax(azmth(indices)+180,0,360);

px = scale*cos(orient*pi/180);
py = scale*sin(orient*pi/180);
x = ptlat(indices); y = ptlon(indices); time = ttsig(indices);
x=x(:);y=y(:);
quiverm(x,y,px,py,'k');
scatterm(x,y,15,time/60,'filled')
colormap(jet)

textm(min(ptlat(indices)),min(ptlon(indices)),[int2str(len),' detections'])
axis off

plotm(srclat,srclon,'rp','MarkerSize',10,'MarkerFaceColor','r')

%colorbar('EastOutside'),grid
cbar = colorbar('Position',[0.75 0.3 0.04 0.4])
ylabel(cbar,'Time (minutes after start of day)')
colormap(jet)
