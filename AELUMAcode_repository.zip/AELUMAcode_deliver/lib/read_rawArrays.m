% read_rawArrays:
%       reads in and does some culling of the array detections
%       returns the detections in vector form
%
% PROGRAM NOTES:
%       1) read in detections; remove if criteria are not satisfied
%           (cross correlation cutoff, consistency cutoff, phase velocity limits &
%           amplitudes)
%       2) compute array centers
%       3) associate each detection with an array
%       4) convert detections to vectors of points
%
% input:
%	fid : file number to read from
%	xccut : lowest allowable cross correlation
%	Tconscut : fractional (signal pair time delay) consistency cutoff
%   vphmin,vphmax : phase velocity limits in km/s
%   Afit - azimuth smoothness requirement
%   fdetmin - minimum allowable F-detector value
%	hr1, hr2 - read in data from hr1 - hr2
%
% output: 
%	detectv : ndetect x 11 matrix of array detections, rows =
%		clat,clon - center of array
%		ttsig,ampsig  - arrival time and amplitude of beamed signal
%		xcorr - average cross-correlation between all station pairs
%		phasevel,azmth - phase velocity and azimuth solution for array
%       taufitt - average fractional consistency in time
%		narray - array number at which detection is made
%       midf  - frequency band number
%	stalat,stalons - station latitudes and logitudes
%	arrayvec - vector that gives the array number for each array
%	narr - number of arrays
%
% History:
%
function [detectv,stalats,stalons,arrayvec,narr] = read_rawArrays(fid,xccut,Tconscut,vphmin,vphmax,Afit,fdetmin,hr1,hr2);

% set a few defaults

veldefault = -1; azdefault = 370;		% default phase velocity & azimuth
xcdefault = 0; taudefault = 2;		    % default xcorr & fractional time misfit
ttbeamdef = -1; ampbeamdef = 0;        % default arrival times and amplitudes
midfdef = -1;                          % default frequency
SPHEROID = referenceEllipsoid('wgs84', 'km');

% ***************************************************************************
%	 Section 1a: read in part of detection file dealing with network
%              configuration
% ***************************************************************************

alldata = fread(fid,'real*4'); fclose(fid);
nsta = alldata(1);  nfin = 1;							% # stations
    
stalats = alldata(nfin+1:nfin+nsta); nfin=nfin+nsta;    % station lats
stalons = alldata(nfin+1:nfin+nsta); nfin=nfin+nsta;    % station longs
narr = alldata(nfin+1);              nfin=nfin+1;	    % # arrays
arrayvec = alldata(nfin+1:nfin+nsta);    nfin=nfin+nsta;   % array number for each station
numf = alldata(nfin+1);    nfin=nfin+1;

% -------------------------------------------------------------------------
%   Section 1b: compute array centers
% -------------------------------------------------------------------------

for jarr = 1:narr
    iii = find(arrayvec==jarr);
    clon(jarr) = mean(stalons(iii));       % array centers
    clat(jarr) = mean(stalats(iii));
end

fprintf('%d arrays %d frequencies\n',narr,numf)

% *************************************************************************
%    Section 2: read in part of detection file dealing with frequency
%              dependent detections
% *************************************************************************

% loop over arrays, then over frequencies to read in tau-p values

ttsigf = []; arrlatf = []; arrlonf = []; ampsigf = []; xcorrf = [];
phasevelf = []; azmthf = []; taufcloudf = []; narrayf = []; midf = [];

for jarr = 1:narr
    for kf = 1:numf
        fbands = alldata(nfin+1:nfin+2);	nfin=nfin+2;
        tsmooth = alldata(nfin+1:nfin+2);   nfin=nfin+2;         % [tsta tlta]
        twinjump = alldata(nfin+1:nfin+2);  nfin=nfin+2;         % [twin tjump]
        tlen = alldata(nfin+1);				nfin=nfin+1;
        if (kf==1)                      % initialize matrices
            [velf,azf,xcf,taufitf,ttbeamf,ampf,midfarr] = deal(zeros(numf,tlen));
        end
        dum = alldata(nfin+1:nfin+tlen);	nfin=nfin+tlen;
        velf(kf,:) = dum;                               % phase velocities in m/s
        dum = alldata(nfin+1:nfin+tlen);	nfin=nfin+tlen;
        azf(kf,:) = dum;
        dum = alldata(nfin+1:nfin+tlen);	nfin=nfin+tlen;
        xcf(kf,:) = dum;
        dum = alldata(nfin+1:nfin+tlen);	nfin=nfin+tlen;
        taufitf(kf,:) = dum;

% arrival times and amplitudes of the beam-formed waveform
% the arrival time is with respect to the centroid location for each array
        dum = alldata(nfin+1:nfin+tlen);	nfin=nfin+tlen;
        ttbeamf(kf,:) = dum;
        dum = alldata(nfin+1:nfin+tlen);	nfin=nfin+tlen;
        ampf(kf,:) = dum;
        midfarr(kf,:) = kf+zeros(tlen,1);           % number, not mean(fbands)
    end  % end loop over frequencies

% -------------------------------------------------------------------------
%   Section 2b: for each array, dump values that don't meet the cutoffs
% -------------------------------------------------------------------------

% throw out values that do not meet the thresholds

    ind = find(ttbeamf<=hr1*3600 | ttbeamf>=hr2*3600 | xcf<xccut | taufitf>Tconscut | ampf<fdetmin | velf>vphmax*1000 | velf<vphmin*1000 );
    ndetect = tlen*numf-length(ind);
    velf(ind) = veldefault; azf(ind) = azdefault;
    xcf(ind) = xcdefault;  taufitf(ind) = taudefault;
    ttbeamf(ind) = ttbeamdef; ampf(ind)=ampbeamdef; midfarr(ind) = midfdef;

    fprintf('\t array %d : %d detections in %d time windows \n',jarr,ndetect,tlen)

% -------------------------------------------------------------------------
%   Section 2c: convert detections for this array to vectors of points
% -------------------------------------------------------------------------
    icl = find(ttbeamf>0);
    npick(jarr) = length(icl);
    if (length(icl)==0) continue;  end
    
    arrlat = clat(jarr)*ones(npick(jarr),1);
    arrlon = clon(jarr)*ones(npick(jarr),1);
    ttsig = ttbeamf(icl); ampsig = ampf(icl);
    xcorr = xcf(icl); taufcloud = taufitf(icl);
    phasevel = velf(icl); azmth = azf(icl);
    fmid = midfarr(icl);
    narray = jarr*ones(size(arrlat));       % save array number

% combine info from all arrays
    ttsigf = [ttsigf(:); ttsig(:)];
    arrlatf = [arrlatf(:); arrlat(:)]; arrlonf = [arrlonf(:); arrlon(:)];
    ampsigf = [ampsigf; ampsig(:)]; xcorrf = [xcorrf; xcorr(:)];
    phasevelf =[phasevelf; phasevel(:)]; azmthf=[azmthf; azmth(:)];
    taufcloudf = [taufcloudf; taufcloud(:)];
    narrayf = [narrayf; narray(:)]; midf = [midf; fmid(:)];

end                 % end loop over arrays, started at for jarr = 1:narr

% ------------- all the data have been read in at this point

clear alldata dum;
ndetect = sum(npick);
fprintf('\t %d detections over %d frequencies, %d arrays \n',ndetect,numf, narr)
if (ndetect==0)
    detectv=[]; stalats=[];stalons=[];arrayvec=[];narr=0; return;
end

% *************************************************************************
%    Section 3: only save families of detections at each triad
% *************************************************************************
                    
% to define a family there must be several (nfam) detections with
% azimuths and arrival times that agree to within Afit and tcut
nfam = 3;       % number to define a family
tcut = twinjump(2);     % smoothing length

[numdet,numdet2,numdet3] = deal(zeros(narr,1));
for jj = 1:narr
    ii = find(narrayf == jj); lii = length(ii);
    numdet(jj) = lii;
    if (lii == 0) continue; end
% get all arrival times and azimuths at the array
    ttsigtri = ttsigf(ii);
    aztri = azmthf(ii);
    if (numdet(jj) < nfam) % set the arrival time and azimuth to default values
        ttsigf(ii) = ttbeamdef;
%        azmthf(ii) = azdefault;
    end
    iflag = zeros(lii,1);     % set to one for a good point
    for jj2 = 1:lii      % check for matching time and azimuth values
% values with nearly matching times and azimuths
        azdiff = abs(Csetminmax(aztri(jj2)-aztri,-180,180));
        itt = find(  abs(ttsigtri(jj2)-ttsigtri) < tcut & azdiff < Afit/2 );
        litt = length(itt);
        if (litt >=nfam);
            iflag(itt) = 1;
        end
    end
    numdet2(jj) = sum(iflag);
    idump = find(iflag==0);
    ttsigf(ii(idump)) = ttbeamdef;
end

ndetect = sum(numdet2);
fprintf('\n %d remain after removal of non-family detections \n',ndetect)
if (ndetect==0) detectv=[]; return; end

% remove detections that do not belong to a family
icl = find(ttsigf>0);
ttsigf = ttsigf(icl);
arrlatf = arrlatf(icl); arrlonf = arrlonf(icl);
ampsigf = ampsigf(icl); xcorrf = xcorrf(icl);
phasevelf = phasevelf(icl); azmthf = azmthf(icl);
taufcloudf = taufcloudf(icl); narrayf = narrayf(icl);
midf = midf(icl);
                    
% now represent each family by 1 member (allow 1 per frequency)
% to vastly reduce the number of detections (by a factor of 3 to 4)
for jj = 1:narr
    if (numdet2(jj) == 0); continue; end
    ii = find(narrayf == jj); lii = length(ii);
    ttsigtri = ttsigf(ii);
    aztri = azmthf(ii);
    midftri = midf(ii);
% if more than one member of family at a given frequency, choose the best based on
% lowest taucloudf (time consistency), (instead of highest amplitude or highest x-corr)
    iflag = zeros(lii,1);     % set to one for a good point
    for jj2 = 1:lii      % check for matching time and azimuth values
        azdiff = abs(Csetminmax(aztri(jj2)-aztri,-180,180));
% save a value for each frequency
        for jjf = 1:numf
            itt = find( (abs(ttsigtri(jj2)-ttsigtri) < tcut) & (azdiff < Afit/2) & (midftri==jjf) );
            litt = length(itt);
  % %%%         [dum,ibest] = max(xcorrf(ii(itt)));     % use Xcorr for triads
            [dum,ibest] = min(taufcloudf(ii(itt)));
            iflag(itt(ibest)) = 1;
        end
    end             % end of jj2 loop
    idump = find(iflag==0);
    ttsigf(ii(idump)) = ttbeamdef;
    numdet3(jj) = sum(iflag);
end
 
ndetect = sum(numdet3);
fprintf('\t %d remain after combining family detections \n',ndetect)
if (ndetect==0) detectv=[]; return; end
 
icl = find(ttsigf>0);
ttsigf = ttsigf(icl);
arrlatf = arrlatf(icl); arrlonf = arrlonf(icl);
ampsigf = ampsigf(icl); xcorrf = xcorrf(icl);
phasevelf = phasevelf(icl); azmthf = azmthf(icl);
taufcloudf = taufcloudf(icl); narrayf = narrayf(icl);
midf = midf(icl);

% *************************************************************************
%    Section 4: now sort by time
% *************************************************************************
[ttsigf,itsort] = sort(ttsigf);
arrlatf = arrlatf(itsort); arrlonf = arrlonf(itsort);
ampsigf = ampsigf(itsort); xcorrf = xcorrf(itsort);
phasevelf = phasevelf(itsort); azmthf = azmthf(itsort);
taufcloudf = taufcloudf(itsort);
narrayf = narrayf(itsort);
midf = midf(itsort);
							 
% *************************************************************************
%	Section 5: return detection info as matrix
% *************************************************************************
							 
detectv = zeros(10,ndetect);
detectv(1,:) = arrlatf; detectv(2,:) = arrlonf;
detectv(3,:) = ttsigf; detectv(4,:) = ampsigf;
detectv(5,:) = xcorrf; detectv(6,:) = phasevelf;
detectv(7,:) = azmthf; detectv(8,:) = taufcloudf;
detectv(9,:) = narrayf; detectv(10,:) = midf;
