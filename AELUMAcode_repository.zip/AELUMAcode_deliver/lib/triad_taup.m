% triad_taup:
%       finds best plane wave azimuth & velocities for an array at 1 frequency
%
% input:
%	filtdat - data in a given time window (nt X 3)
%	fsamp - sampling rate
%	XR - [nseries by 2] matrix of receiver locations
%   mwin - number of windows
%   ibeg, iend - beginning and endpoints of each windows
%   vmin - minimum possible phase velocity across array
%   tmiscut - tau ratio cutoff (0.1 suggested)
%   snrcutm1 = snrcut - 1 (applied to envelopes - 1 (for ifenv=1))
%   ifenv - only reject windows for ifenv==1 if snr is too low
%
% output: 
%	plvec - plane wave velocities	(1 * time points)
%	azvec - plane wave azimuths		(1 * time points)
%   xcor - average x-correlation for best plane wave    (1 * time points)
%	fitvec - (fractional) time fit for best plane wave	(1 * time points)
%   ttvec,ampvec - time (seconds) and amplitude of maximum beam for each window
% 

function [plvec,azvec,xcor,fitvec,ttvec,ampvec] = triad_taup(filtdat,fsamp,XR,mwin,ibeg,iend,vmin,tmiscut,snrcutm1,ifenv);

[xlen,msta] = size(filtdat);
nrow = 3;
xloc = XR(:,1); yloc = XR(:,2);

% construct Amat - relative position matrix
% (do this once per frequency, in arrayConfiguration.m)
Amat = zeros(nrow,2);
%staPairs = zeros(nrow,3);       % stations pairs & interstation distances
rdist=zeros(nrow,1);
icount = 0;
for ksta = 1: msta-1
    for kk = ksta+1:msta
        icount = icount + 1;
        Amat(icount,1) = xloc(kk)-xloc(ksta);
        Amat(icount,2) = yloc(kk)-yloc(ksta);
%        staPairs(icount,1) = ksta;
%        staPairs(icount,2) = kk;
%        staPairs(icount,3) = sqrt(Amat(icount,1)*Amat(icount,1) + Amat(icount,2)*Amat(icount,2));
        rdist(icount) = sqrt(Amat(icount,1)*Amat(icount,1) + Amat(icount,2)*Amat(icount,2));
    end
end
solMatrix = inv(Amat'*Amat)*Amat';
maxlagn = ceil(fsamp*1.5*max(rdist/1000)/vmin);
                  
% *************************************************************************

% for method, see Chapter_9.pdf (on Mac) Array Processing from
% Routine data Processing in Earthquake Seismology
% for more see NMSOP.pdf (Manual of Seismological Observatory Practice)

% ~~~~~~~~~~~~~~~~ initialize values ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

plvec = -10+zeros(mwin,1); azvec = 380+zeros(mwin,1);
ttvec = zeros(mwin,1); ampvec=zeros(mwin,1);
xcor = zeros(mwin,1); fitvec = ones(mwin,1);
fdet = 1;

%  loop over each time window at a given array
for jwin = 1:mwin
                    
    nr1 = ibeg(jwin); nr2 = iend(jwin);
    xseglen = nr2-nr1+1; maxlag = min(maxlagn,xseglen-1);
    dataseg = filtdat(nr1:nr2,:);          % switch order to (nt X msta)
 
    if (ifenv)
% ALL 3 envelopes within the triad must have a given minimum snr (skip this?))
        if (min(max(abs(dataseg)))<snrcutm1) continue; end
    end
                
    [tau,xmag] = Nxcorr(dataseg,fsamp,maxlag,nrow);
    fitvec(jwin) = abs(tau(1) + tau(3) - tau(2))/sum(abs(tau));
    xcor(jwin) = (xmag(1) + xmag(2) + xmag(3))/nrow;
    
    if (fitvec(jwin) > tmiscut) continue; end
                  
% fit is acceptable, compute phase velocity, azimuth, etc
                
    psol = solMatrix *tau;
    px = psol(1);  py=psol(2);
    theta = atan2(px,py)*180/pi;
    plazm = Csetminmax(theta,0,360);
    plvel = sqrt(1/(px*px+py*py));
    azvec(jwin) = plazm;
    plvec(jwin) = plvel;
                                
% make a beam-formed waveform for the given velocity & azimuth
    obeam = beamform(dataseg,fsamp,plazm,plvel,XR);
    [omax,itt] = max(obeam);
% get arrival time and scaled amplitude
    ttvec(jwin) = (nr1+itt-1)/fsamp;      % time in seconds
    ampvec(jwin) = omax;

end          % end loop over time windows for a triad
return
                
% ----------------------------------------------------------------------------------
% for debugging, comment out end and return lines, just above
                
% plot a data figure to show how this works in practice
% plot a window for which   fitvec is low  (< 0.1)
%                            xcor is not great (between 0.3 - 0.5)
%                            ampvec > 6
% the point is to show an example of a window where we get a good result (fitvec)
% but data are noisy (xcor is only OK)
           
        if (ampvec(jwin) > 6 & plvel < 9000)
            jwin
            tsave = [0:nr2-nr1]/fsamp;
            figure(3),clf,axes('position',[0.1 0.34 0.48 0.4])
            for kk = 1:msta
                signal = dataseg(:,kk);
                scale = max(abs(signal));
                data = 0.5*signal/scale;
                plot(tsave,kk+data,'k','LineWidth',1),hold on
            end
            ylim([0 msta+1]), ylabel('Station Number')
            xlim([tsave(1) tsave(end)]),
            grid
            h=gca,set(h,'XTickLabel',[])

            axes('position',[0.1 0.1 0.48 0.2])
            plot(tsave,obeam,'k','LineWidth',1), grid, hold on
            xlim([tsave(1) tsave(end)]),
            xlabel('Time (s)')
                                
            disp('testing in triad_taup, line 146')
            keyboard
                                
        end
 %end
 %return
