%  AELUMA public bundle
%
% distmatrix: 
%       find distances between all station pairs and return result
%       also find the minimum distance between a station and all others  
%       assumes latitude/longitude
%
% input:
%       stalat,stalon- input vectors of station latitudes & longitudes 
% output:
%       distmat - matrix of distances between stations (km)
%       distmin - minimum distance to nearest station (km)
%       distmin2 - minimum distance to 2nd nearest station (km)
%       distmin3 - minimum distance to 3rd nearest station (km)
%
% History:
%       R.2016.336 2016-12-01 IRIC DMC: public release
%
% usage:
%       [distmat,distmin,distmin2,distmin3] = distmatrix(stalat,stalon);
%
function [distmat,distmin,distmin2,distmin3] = distmatrix(stalat,stalon)
% fprintf('\n[INFO] staring distmatrix\n\n');
npts = length(stalat);
if npts ~=length(stalon)
   disp('WARNING: must be equal number of station latitudes and longitudes')
   return
end

stalon=stalon(:); stalat=stalat(:);
xy=[stalon stalat];

% Calculate the distance matrix for all of the cities
distmat = zeros(npts);
for count1=1:npts,
    x1 = xy(count1,1); y1 = xy(count1,2);
    for count2=1:count1,
        x2 = xy(count2,1); y2 = xy(count2,2);
        lonscale = cosd((y1+y2)/2);
        distmat(count1,count2)=sqrt((lonscale*(x1-x2))^2+(y1-y2)^2)*111.11;    % distance in km
        distmat(count2,count1)=distmat(count1,count2);
    end;
%    distmat(count1,count1) = max(distmat(count1,:));    % replace diagonal with large value
end;
dmax=max(distmat(:));
for ii=1:npts
  distmat(ii,ii) = 2*dmax;
%    distmat(ii,ii) = 1/eps;
end

distmin = min(distmat);                 % the distance to the nearest neighbour
% want to get the distance to the 2nd nearest neighbour too
sdmat=sort(distmat); distmin2 = sdmat(2,:); distmin3 = sdmat(3,:);

% fprintf('\n[INFO] distmatrix done\n\n');
return
figure(11),clf,imagesc(distmat);colorbar('vert')
figure(12),clf,plot(distmin),hold on,plot((distmin+distmin2+distmin3)/3,'r')
