% select DMC stations to read in
% 1) set paths
% 2) divide the groups of stations into arrays
%       given maximum array diameter and minimum number of sensors within the array
%       throw out stations that are not part of an array
%
% *********************************************************************************************
% *********************************************************************************************
%
%    section 1- set directories 
%
% *********************************************************************************************
% *********************************************************************************************
fprintf('\n---> section 1 - set directories & WS calls\n\n');

% overwrite output directory
Dir               = sprintf('%s/%4i/',detectionDir,iyr);
[s, mess, messid] = mkdir(Dir);
fprintf('[INFO] output directory: %s  %s\n', Dir, mess);

%
% added to support irisFetch
%
channelStart = dayStart;
channelEnd   = dayEnd;
%
% web services expects '--' for blank location code
%
requestLoc = checkLocCode(loc);

st           = irisFetch.Channels('CHANNEL',net,'*',requestLoc,chan,'EndAfter',channelStart,'StartBefore',channelEnd);
fprintf('[INFO]irisFetch call: CHANNEL:%s,LOC:%s,CHAN:%s,START:%d,END:%d\n',net,requestLoc,chan,channelStart,channelEnd)
fprintf('[INFO]irisFetch stations record length: %d\n',length(st));

% *********************************************************************************************
% *********************************************************************************************
%
%    section 2- cull stations - several different culling methods 
%
% *********************************************************************************************
% *********************************************************************************************

fprintf('\n---> section 2 - cull stations: several different culling methods\n\n');

%
% st - structure for station names, locations,etc, changes to support irisFetch
% st.lat --> st.Latitude st.lon --> st.Longitude st.offdate --> st.EndDate st.ondate --> st.StartDate
%
nstat      = length([st.Longitude]);
stalons    = [st.Longitude]; stalats=[st.Latitude];
dum=[sprintf('%5s',st.StationCode)];
dum=reshape(dum,5,length(dum)/5);
stacode=dum'  ;
nstat=length(stalats);
fprintf('[INFO] %i stations retrieved\n',nstat);

getTraceData;

if makeplots ~= 0
	fig_h = figure(5);clf;
	states = shaperead('usastatehi', 'UseGeoCoords', true);
    set (fig_h,'Position',[1 150 screenWidth screenHeight],'Color',[1 1 1]);
	geoshow(states,'FaceColor',0.99*[1 1 1],'EdgeColor',.6*[1 1 1]);
    load coast
    hold on,geoshow(lat,long,'Color',0.01*[1 1 1])
	hold on, plot(stalons,stalats,'ko','MarkerFaceColor',0.6*[1 1 1])
	%axis([min(stalons) max(stalons) min(stalats) max(stalats)])
	axis([wlon elon southlat northlat])
end
%
% cull station lists
%
% A) only use data if sample rate is within range fsmin-fsmax and sample rate is divisible by fsmin
%  ii = find( (fsamp>=fsmin) & (fsamp<=fsmax) & mod((fsamp/fsmin),1)==0);
ii = find( (fsamp>=fsmin) & (fsamp<=fsmax) & (fsamp>=2*fmax) );
fprintf('[INFO] %i records have sample rates >= %d & <= %d Hz\n',length(ii),fsmin,fsmax);
fprintf('[INFO] and >= 2*%d Hz\n',fmax);

chaname=chaname(ii,:); 
endt = endt(ii); fsamp = fsamp(ii); 
scl = scl(ii); startt = startt(ii);
wfname = wfname(ii,:); 
nwfdisc = length(ii);

%
% We do not have availability data from irisFetch,
% so for TA stations we assume that having metadata means that we have data.
% after we create the triads, we will reject those that have no data
%
% B) include only stations that are both in site list and wfdisc
[ms1,ls1] = size(strtrim(stacode));     % ls1 is max string length of stacode
[ms2,ls2] = size(strtrim(wfname));      % ls2 is max string length of wfname
ikeep = [];
if ls1 > ls2
    for jj = ms1:-1:1          % get rid of stations with names that are too long
        if (length(strtrim(stacode(jj,:))) > ls2)
            stacode(jj,:) = [];
        else
            ikeep = [ikeep jj];
        end
    end
    st=st(sort(ikeep));
end
if ls2 > ls1
    for jj = ms2:-1:1          % get rid of stations with names that are too long
        if (length(strtrim(wfname(jj,:))) > ls1)
            wfname(jj,:) = [];
        end
    end
end

fprintf('\n[INFO] stacode and wfdisc names have lengths %d  %d, respectively \n',ls1,ls2);

fprintf('\n[WARN] for TA stations we assume the metadata availability is the same as data availability\n\n');
[c,ia,ib] = intersect(strtrim(stacode),wfname,'rows');
st=st(ia);
stalats=[st.Latitude]; stalons = [st.Longitude];
nstat=length(stalats);

if makeplots ~= 0
    hold on,plot(stalons,stalats,'ko','MarkerFaceColor','y')
end
fprintf('[INFO] number of available stations: %d\n', nstat);

if (ifregion)
% Q) get rid of stations if they are not within the region of interest
    ind = find(stalons>=lon1 & stalons<=lon2 & stalats>=lat1 & stalats<=lat2);

    st=st(ind); stalats=[st.Latitude]; stalons = [st.Longitude];
    nstat=length(stalats);
    fprintf('\t stations within region of interest : \t \t \t  %d\n',nstat)
end

% to eliminate some regions
if (ifexclusion>0)
    for iex = 1:ifexclusion
        ifexloc = [ifexlon(iex,1) ifexlon(iex,2) ifexlat(iex,1) ifexlat(iex,2)];
        ii = find(stalons>=ifexloc(1) & stalons<=ifexloc(2) & stalats>=ifexloc(3) & stalats<=ifexloc(4));
        kk=1:nstat; ind=setdiff(kk,ii);
        st = st(ind);
        stalats=[st.Latitude]; stalons = [st.Longitude];
        nstat=length(stalats);
        clear kk ii
    end
    fprintf('\t after eliminating stations in exclusion zones:  \t  %d\n',nstat)
end

% D) get rid of stations if they are too near other stations
[distmat,distmin,distmin2,distmin3] = distmatrix(stalats,stalons);
mindist = min(distmin);

while (mindist<rmin)
    ii1 = find(distmin==mindist);        % find stations with minimum interstation R
% ii1 list comprises at least 2 stations, cull the one with smallest distmin2
    [dum2,ii2] = min(distmin2(ii1));
    ii = ii1(ii2);
    kk=1:nstat; ind=setdiff(kk,ii);
    st=st(ind);
    stalats=[st.Latitude]; stalons = [st.Longitude];
    nstat=length(stalats);
    [distmat,distmin,distmin2,distmin3] = distmatrix(stalats,stalons);
    mindist = min(distmin);
%    [nstat mindist min(distmin2)]
end
fprintf('\t > %d km from nearest neighbour : \t %d\n\n',rmin,nstat)

if makeplots ~= 0
    stalats=[st.Latitude]; stalons = [st.Longitude];
    hold on,plot(stalons,stalats,'ko','MarkerFaceColor','b')
end

% get rid of stations that are too far from other stations 
Dmax = 2*Rmax;
% C) get rid of stations if they are too far from others
nstatold = 0;
while (nstatold < nstat)
    nstatold = nstat;
    [distmat,distmin,distmin2,distmin3] = distmatrix(stalats,stalons);
    sdsort = sort(distmat); distminarr = sdsort(namin-1,:);
    ind = find(distminarr<Dmax);
    st=st(ind); stalats=[st.Latitude]; stalons = [st.Longitude];
    nstat=length(stalats);
end
fprintf('\t < %d km from enough nearest neighbours for array: \t %d\n',Dmax,nstat)

staondate = jdate({st.StartDate});
% staoffdate = jdate({st.EndDate});

% put in a dummy end date if the station is still on
for kk=1:nstat
    if (isempty(st(kk).EndDate))
        staoffdate(kk) = 2099001;      % some time in the future
    else
        staoffdate(kk) = jdate({st(kk).EndDate});
    end
end
staondate=staondate(:); staoffdate=staoffdate(:);

% save list of stations
nstato=nstat; sto=st; stalatso=stalats; stalonso=stalons;
staondateo=staondate; staoffdateo=staoffdate;
if makeplots ~= 0
	hold on,plot(stalons,stalats,'ko','MarkerFaceColor','m')
    pause(0.001)
end

return
