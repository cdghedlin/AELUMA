% AELUMA public bundle
%
% ep2dat:
%       Converts epochal time to yr,day,hr,mn,sec
%       epochal time is defined by CSS to
%       be the time in secs from 1970 day 0.
% 
% input:
%       time
%
% output:
%       iy = year
%       id = day of year (often called Julian day)
%       ih = hour of day
%       im = minutes
%       ss = seconds
%
% History:
%       2009 Bob Woodward: originator
%       2009-11-30 Manoch: installed at DMC
%       2010-04-22 Manoch: noticed that for time past middle of the day it returnd next dat and also
%                        returns negative time elements. The foloowing fix was applied after
%                        many tests that all failed!!!
%       R.2016.336 2016-12-01 IRIC DMC: public release
%
function [iy, id, ih, im, ss] =  ep2dat(time)

      if time < 0.0
        error('ERROR in ep2dat -- epochal time < 0');
      end;
      nd  = time / 86400.;
      kd  = fix(nd);
      sec = time - (86400. * kd);
     
      % 
      % this is workaround for a problem that is observed with fix!
      % it appears that fix does not round down towards the smaller
      % integer when greater that 0.5. All tests failed ...manoch 2010-04-22
      %
      if(sec < 0)
         kd = kd - 1;
         sec = time - (86400. * kd);
      end;

      ky  = 1970;
      idpy = 365;
      
      while kd >= idpy
          ky = ky + 1;
          kd = kd - idpy;
          idpy = 365;
          if mod(ky,4) == 0
              idpy=366;
          end;
      end;
      iy = ky;
      id = kd + 1;
      nh = sec / 3600.d0;
      ih = fix(nh);
      nm = (sec - (3600.d0 * ih)) / 60.d0 ;
      % 
      % this is workaround for a problem that is observed with fix!
      % it appears that fix does not round down towards the smaller
      % integer when greater that 0.5. All tests failed ...manoch 2010-04-22
      %
      if(nm < 0)
         ih = ih - 1;
         nm = (sec - (3600.d0 * ih)) / 60.d0 ;
      end;
      im = fix(nm);
      ss = sec - 3600.d0*ih - 60.d0*im;

      % 
      % this is workaround for a problem that is observed with fix!
      % it appears that fix does not round down towards the smaller
      % integer when greater that 0.5. All tests failed ...manoch 2010-04-22
      %
      if(ss < 0)
         im = im - 1;
         ss = sec - 3600.d0*ih - 60.d0*im;
      end;

