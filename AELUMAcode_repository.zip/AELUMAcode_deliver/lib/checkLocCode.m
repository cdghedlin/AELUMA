% AELUMA public bundle
%
% checkLocCode:
%       updates location code, if needed in support of web services
%
% History:
%       2017-02-02 Manoch: created
%
function [updatedLoc] = checkLocCode(loc)
   %
   % web services expects '--' for blank location code
   %
   updatedLoc = strtrim(loc);
   if length(updatedLoc) == 0
      updatedLoc = '--';
   end;
